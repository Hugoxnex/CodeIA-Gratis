const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const { flattenFilePaths } = require('./tree-utils');

let mainWindow;
let workspace = null;
let activeChild = null;
const OLLAMA = 'http://127.0.0.1:11434';
const MAX_FILE_BYTES = 2 * 1024 * 1024;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 940,
    minWidth: 1050,
    minHeight: 680,
    backgroundColor: '#17191f',
    title: 'Oficina IA',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (activeChild) activeChild.kill(); });

function send(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}

function requireWorkspace() {
  if (!workspace) throw new Error('Abra uma pasta de projeto primeiro.');
  return workspace;
}

function isInside(root, target) {
  const relative = path.relative(root, target);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function cleanRelativePath(value) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('Caminho de arquivo vazio.');
  const normalized = value.replace(/\\/g, '/').replace(/^\.\//, '');
  if (path.isAbsolute(normalized) || normalized.split('/').some(part => !part || part === '.' || part === '..')) {
    throw new Error(`Caminho inválido: ${value}`);
  }
  if (normalized.split('/').some(part => ['.oficina-backups', 'node_modules', '.git'].includes(part))) {
    throw new Error(`Caminho reservado: ${value}`);
  }
  return normalized;
}

async function safeTarget(relative, allowMissing = false) {
  const root = requireWorkspace();
  const clean = cleanRelativePath(relative);
  const target = path.resolve(root, clean);
  if (!isInside(root, target)) throw new Error('Caminho fora da pasta do projeto.');
  let parent = path.dirname(target);
  while (parent !== root) {
    try {
      const st = await fs.lstat(parent);
      if (st.isSymbolicLink()) throw new Error('Não é permitido gravar por links simbólicos.');
      parent = path.dirname(parent);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      parent = path.dirname(parent);
    }
  }
  try {
    const st = await fs.lstat(target);
    if (st.isSymbolicLink()) throw new Error('Links simbólicos não podem ser abertos ou alterados.');
    const real = await fs.realpath(target);
    if (!isInside(root, real)) throw new Error('Arquivo fora da pasta do projeto.');
    return { target: real, clean };
  } catch (error) {
    if (error.code === 'ENOENT' && allowMissing) return { target, clean };
    throw error;
  }
}

async function listTree(dir = '', depth = 0, budget = { count: 0 }) {
  const root = requireWorkspace();
  if (depth > 5 || budget.count > 400) return [];
  const abs = dir ? (await safeTarget(dir)).target : root;
  const entries = await fs.readdir(abs, { withFileTypes: true });
  const ignored = new Set(['node_modules', '.git', '.oficina-backups', '.next', 'dist', 'build', '.venv', '__pycache__']);
  const result = [];
  for (const entry of entries.sort((a, b) => (a.isDirectory() === b.isDirectory() ? a.name.localeCompare(b.name) : a.isDirectory() ? -1 : 1))) {
    if (entry.name.startsWith('.') || ignored.has(entry.name) || entry.isSymbolicLink()) continue;
    budget.count++;
    const rel = dir ? `${dir}/${entry.name}` : entry.name;
    if (entry.isDirectory()) result.push({ name: entry.name, path: rel, type: 'folder', children: await listTree(rel, depth + 1, budget) });
    else result.push({ name: entry.name, path: rel, type: 'file' });
    if (budget.count > 400) break;
  }
  return result;
}

ipcMain.handle('app:platform', () => ({ platform: process.platform, version: app.getVersion(), workspace }));
ipcMain.handle('workspace:open', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory', 'createDirectory'] });
  if (result.canceled || !result.filePaths[0]) return null;
  workspace = await fs.realpath(result.filePaths[0]);
  return { path: workspace, tree: await listTree() };
});
ipcMain.handle('workspace:refresh', async () => ({ path: requireWorkspace(), tree: await listTree() }));
ipcMain.handle('workspace:context', async () => {
  const paths = [];
  for (const rel of flattenFilePaths(await listTree())) {
    if (paths.length >= 18) break;
    if (/\.(png|jpe?g|gif|webp|pdf|zip|exe|dll|so|dylib|lock|woff2?|ttf|mp4|mp3)$/i.test(rel)) continue;
    paths.push(rel);
  }
  let context = '';
  for (const rel of paths) {
    try {
      const { target } = await safeTarget(rel);
      const stat = await fs.stat(target);
      if (!stat.isFile() || stat.size > 5000) continue;
      const content = await fs.readFile(target, 'utf8');
      if (content.includes('\u0000')) continue;
      context += `\n--- ${rel} ---\n${content}\n`;
      if (context.length >= 40000) break;
    } catch (_) { /* arquivos que mudaram durante a leitura são ignorados */ }
  }
  return context.slice(0, 40000);
});
ipcMain.handle('workspace:new-file', async (_event, relative) => {
  const { target } = await safeTarget(relative, true);
  await fs.mkdir(path.dirname(target), { recursive: true });
  try { await fs.writeFile(target, '', { flag: 'wx' }); }
  catch (e) { if (e.code === 'EEXIST') throw new Error('Esse arquivo já existe.'); throw e; }
  return { path: relative };
});
ipcMain.handle('file:read', async (_event, relative) => {
  const { target, clean } = await safeTarget(relative);
  const stat = await fs.stat(target);
  if (!stat.isFile()) throw new Error('O caminho selecionado não é um arquivo.');
  if (stat.size > MAX_FILE_BYTES) throw new Error('Arquivo maior que 2 MB; não foi carregado no editor.');
  return { path: clean, content: await fs.readFile(target, 'utf8') };
});
ipcMain.handle('file:write', async (_event, relative, content) => {
  const { target } = await safeTarget(relative);
  if (Buffer.byteLength(String(content), 'utf8') > MAX_FILE_BYTES) throw new Error('Arquivo maior que 2 MB.');
  await fs.writeFile(target, String(content), 'utf8');
  return { ok: true };
});
ipcMain.handle('files:apply-generated', async (_event, files) => {
  const root = requireWorkspace();
  if (!Array.isArray(files) || files.length > 40) throw new Error('Lista de arquivos inválida (limite: 40).');
  const backupStamp = new Date().toISOString().replace(/[:.]/g, '-');
  const written = [];
  for (const item of files) {
    const { target, clean } = await safeTarget(item.path, true);
    const content = String(item.content ?? '');
    if (Buffer.byteLength(content, 'utf8') > MAX_FILE_BYTES) throw new Error(`${clean}: arquivo excede 2 MB.`);
    await fs.mkdir(path.dirname(target), { recursive: true });
    try {
      const oldStat = await fs.lstat(target);
      if (oldStat.isSymbolicLink() || !oldStat.isFile()) throw new Error(`Não é seguro sobrescrever ${clean}.`);
      const backup = path.join(root, '.oficina-backups', backupStamp, clean);
      await fs.mkdir(path.dirname(backup), { recursive: true });
      await fs.copyFile(target, backup);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    await fs.writeFile(target, content, 'utf8');
    written.push(clean);
  }
  return { written, backupDirectory: path.join(root, '.oficina-backups', backupStamp) };
});

ipcMain.handle('ollama:status', async () => {
  try {
    const response = await fetch(`${OLLAMA}/api/tags`, { signal: AbortSignal.timeout(2500) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    return { ok: true, models: (data.models || []).map(m => m.name) };
  } catch (_) {
    return { ok: false, models: [], message: 'Ollama não respondeu em 127.0.0.1:11434.' };
  }
});
ipcMain.handle('ollama:generate', async (_event, { model, prompt, context }) => {
  if (!model) throw new Error('Escolha um modelo do Ollama.');
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,120}$/.test(model)) throw new Error('Nome de modelo inválido.');
  const response = await fetch(`${OLLAMA}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      stream: false,
      format: 'json',
      options: { temperature: 0.2 },
      messages: [
        { role: 'system', content: 'Você é um engenheiro de software sênior. Responda SOMENTE com JSON válido neste formato: {"summary":"resumo curto em português","files":[{"path":"caminho/relativo/arquivo.ext","content":"conteúdo integral do arquivo"}]}. Gere apenas os arquivos necessários; se o projeto estiver vazio, crie o projeto mínimo funcional. Nunca use caminhos absolutos, .., marcadores Markdown ou blocos de código. Não inclua node_modules, segredos ou arquivos binários. Respeite a linguagem do pedido do usuário.' },
        { role: 'user', content: `PEDIDO:\n${String(prompt || '').slice(0, 12000)}\n\nARQUIVOS EXISTENTES DO PROJETO (contexto parcial):\n${String(context || '').slice(0, 40000)}\n\nCrie ou altere os arquivos necessários. Retorne JSON válido, sem texto antes/depois.` }
      ]
    }),
    signal: AbortSignal.timeout(300000)
  });
  if (!response.ok) throw new Error(`Ollama respondeu com HTTP ${response.status}. Verifique modelo e serviço.`);
  const data = await response.json();
  const raw = data.message?.content || '';
  let result;
  try { result = JSON.parse(raw); }
  catch (_) {
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('A resposta do modelo não veio em JSON válido. Tente novamente ou use outro modelo.');
    result = JSON.parse(match[0]);
  }
  if (!Array.isArray(result.files)) throw new Error('A resposta não trouxe a lista de arquivos esperada.');
  const files = result.files.slice(0, 40).map(f => ({ path: cleanRelativePath(f.path), content: String(f.content ?? '') }));
  return { summary: String(result.summary || 'Arquivos preparados.'), files };
});
ipcMain.handle('ollama:pull', async (_event, model) => {
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,120}$/.test(String(model))) throw new Error('Nome de modelo inválido.');
  const response = await fetch(`${OLLAMA}/api/pull`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: model, stream: true }), signal: AbortSignal.timeout(1800000)
  });
  if (!response.ok) throw new Error(`Não foi possível baixar o modelo (HTTP ${response.status}).`);
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let pending = '';
  while (true) {
    const { value, done } = await reader.read();
    pending += decoder.decode(value || new Uint8Array(), { stream: !done });
    const lines = pending.split('\n');
    pending = lines.pop() || '';
    for (const line of lines) {
      if (!line.trim()) continue;
      const item = JSON.parse(line);
      if (item.error) throw new Error(item.error);
      const percent = item.total ? Math.floor((item.completed / item.total) * 100) : null;
      send('ollama:pull-progress', { status: item.status || 'Baixando modelo', percent });
    }
    if (done) break;
  }
  send('ollama:pull-progress', { status: 'Modelo instalado', percent: 100 });
  return { ok: true };
});
ipcMain.handle('ollama:open-download', async () => {
  await shell.openExternal('https://ollama.com/download');
  return { ok: true };
});

function tokenize(input) {
  const tokens = input.match(/(?:"[^"\\]*(?:\\.[^"\\]*)*"|'[^'\\]*(?:\\.[^'\\]*)*'|[^\s]+)/g) || [];
  return tokens.map(t => {
    if ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'"))) return t.slice(1, -1);
    return t;
  });
}
ipcMain.handle('terminal:run', async (_event, command) => {
  if (activeChild) throw new Error('Já existe um comando em execução. Pare-o antes de iniciar outro.');
  const cwd = requireWorkspace();
  const tokens = tokenize(String(command || '').trim());
  if (!tokens.length) throw new Error('Digite um comando para executar.');
  if (tokens.some(t => /[;&|<>`$\n\r]/.test(t))) throw new Error('Comandos em cadeia e operadores de shell não são aceitos. Execute um comando por vez.');
  const executable = tokens.shift();
  send('terminal:data', `\r\n$ ${command}\r\n`);
  return new Promise((resolve, reject) => {
    let finished = false;
    let timeout;
    const child = spawn(executable, tokens, { cwd, shell: false, windowsHide: true, env: process.env });
    activeChild = child;
    const done = (result) => { if (finished) return; finished = true; clearTimeout(timeout); activeChild = null; send('terminal:done', result); resolve(result); };
    child.stdout.on('data', data => send('terminal:data', data.toString()));
    child.stderr.on('data', data => send('terminal:data', data.toString()));
    child.on('error', error => { send('terminal:data', `\r\n${error.message}\r\n`); done({ code: -1, error: error.message }); });
    child.on('close', code => done({ code: code ?? -1 }));
    timeout = setTimeout(() => { if (activeChild === child) child.kill(); }, 10 * 60 * 1000);
  });
});
ipcMain.handle('terminal:stop', async () => { if (activeChild) activeChild.kill(); return { ok: true }; });
ipcMain.handle('app:external', async (_event, url) => {
  if (typeof url !== 'string' || !url.startsWith('https://ollama.com/')) throw new Error('Link externo não permitido.');
  await shell.openExternal(url);
});
