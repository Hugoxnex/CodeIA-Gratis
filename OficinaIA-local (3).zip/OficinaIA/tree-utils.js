function flattenFilePaths(nodes) {
  if (!Array.isArray(nodes)) return [];
  return nodes.flatMap(node => {
    if (!node || typeof node !== 'object') return [];
    if (node.type === 'file' && typeof node.path === 'string') return [node.path];
    if (node.type === 'folder') return flattenFilePaths(node.children);
    return [];
  });
}

module.exports = { flattenFilePaths };
