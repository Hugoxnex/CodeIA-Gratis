const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('oficina', {
  platform: () => ipcRenderer.invoke('app:platform'),
  openWorkspace: () => ipcRenderer.invoke('workspace:open'),
  refreshWorkspace: () => ipcRenderer.invoke('workspace:refresh'),
  projectContext: () => ipcRenderer.invoke('workspace:context'),
  newFile: (relative) => ipcRenderer.invoke('workspace:new-file', relative),
  readFile: (relative) => ipcRenderer.invoke('file:read', relative),
  writeFile: (relative, content) => ipcRenderer.invoke('file:write', relative, content),
  applyGeneratedFiles: (files) => ipcRenderer.invoke('files:apply-generated', files),
  ollamaStatus: () => ipcRenderer.invoke('ollama:status'),
  generate: (payload) => ipcRenderer.invoke('ollama:generate', payload),
  pullModel: (model) => ipcRenderer.invoke('ollama:pull', model),
  openOllamaDownload: () => ipcRenderer.invoke('ollama:open-download'),
  runCommand: (command) => ipcRenderer.invoke('terminal:run', command),
  stopCommand: () => ipcRenderer.invoke('terminal:stop'),
  openExternal: (url) => ipcRenderer.invoke('app:external', url),
  onTerminalData: (callback) => ipcRenderer.on('terminal:data', (_event, data) => callback(data)),
  onTerminalDone: (callback) => ipcRenderer.on('terminal:done', (_event, result) => callback(result)),
  onPullProgress: (callback) => ipcRenderer.on('ollama:pull-progress', (_event, data) => callback(data))
});
