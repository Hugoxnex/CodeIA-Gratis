#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js/npm não encontrado. Instale gratuitamente a versão LTS em https://nodejs.org/"
  exit 1
fi
if [ ! -d node_modules/electron ]; then
  echo "Instalando dependências gratuitas do aplicativo (requer internet na primeira vez)…"
  npm install
fi
npm start
