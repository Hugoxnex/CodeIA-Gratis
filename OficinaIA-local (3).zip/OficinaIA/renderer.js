const $ = (id) => document.getElementById(id);
const state = { workspace: null, tree: [], currentFile: null, dirty: false, proposal: null, model: null, ollamaReady: false, busy: false };
const icons = { js: 'JS', jsx: 'JS', ts: 'TS', tsx: 'TS', html: '◇', css: '#', json: '{}', md: 'M↓', py: 'Py', sh: '$_', bat: '$_', yml: '⚙', yaml: '⚙', txt: '≡', default: '·' };

function toast(message, type = '') {
  const el = $('toast'); el.textContent = message; el.className = `toast ${type}`;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.add('hidden'), 3600);
}
function setStatus(message) { $('statusWorkspace').textContent = message; }
function extName(filename) { return (filename.split('.').pop() || 'txt').toLowerCase(); }
function iconFor(filename) { const ext = extName(filename); return icons[ext] || icons.default; }
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function getFiles(nodes = state.tree, result = []) { for (const n of nodes) { if (n.type === 'file') result.push(n.path); else getFiles(n.children || [], result); } return result; }

function renderTree(nodes = state.tree, depth = 0) {
  if (!nodes.length && depth === 0) return '<div class="tree-hint">Pasta vazia — crie um arquivo ou peça para a IA.</div>';
  return nodes.map(node => {
    const indent = `style="--depth:${depth}"`;
    if (node.type === 'folder') return `<div class="tree-folder" ${indent}><span class="folder-arrow">⌄</span><span class="folder-icon">▰</span><span>${escapeHtml(node.name)}</span></div>${renderTree(node.children || [], depth + 1)}`;
    return `<button class="tree-file ${state.currentFile === node.path ? 'selected' : ''}" data-file="${escapeHtml(node.path)}" ${indent}><span class="file-icon fi-${extName(node.name)}">${escapeHtml(iconFor(node.name))}</span><span>${escapeHtml(node.name)}</span></button>`;
  }).join('');
}
function showWorkspace(result) {
  if (!result) return;
  state.workspace = result.path; state.tree = result.tree || [];
  const name = result.path.split(/[\\/]/).filter(Boolean).pop() || result.path;
  $('workspaceName').textContent = name; $('projectLabel').textContent = name.toUpperCase(); $('statusWorkspace').textContent = result.path;
  $('fileTree').innerHTML = renderTree(); $('assistantContext').innerHTML = `<span class="context-dot ready"></span><span>Projeto aberto: ${escapeHtml(name)} · ${getFiles().length} arquivo(s)</span>`;
  document.querySelectorAll('.tree-file').forEach(button => button.addEventListener('click', () => openFile(button.dataset.file)));
  $('welcome').classList.add('hidden'); if (!state.currentFile) $('editorWrap').classList.add('hidden');
}
async function refreshTree() {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  try { showWorkspace(await window.oficina.refreshWorkspace()); } catch (e) { toast(e.message, 'error'); }
}
async function openFile(relative) {
  if (state.dirty && !confirm('Há alterações não salvas. Abrir outro arquivo sem salvar?')) return;
  try {
    const file = await window.oficina.readFile(relative); state.currentFile = file.path; state.dirty = false;
    $('codeEditor').value = file.content; $('filePathLabel').textContent = file.path; $('saveState').textContent = 'Salvo';
    $('editorWrap').classList.remove('hidden'); $('welcome').classList.add('hidden'); $('languageLabel').textContent = extName(file.path);
    $('tabs').innerHTML = `<div class="tab active"><span class="tab-file-icon">${escapeHtml(iconFor(file.path))}</span>${escapeHtml(file.path.split('/').pop())}<button id="tabClose" class="tab-close">×</button></div>`;
    $('tabClose').addEventListener('click', () => { state.currentFile = null; $('editorWrap').classList.add('hidden'); $('welcome').classList.remove('hidden'); $('tabs').innerHTML = '<div class="tab placeholder-tab">Bem-vindo</div>'; });
    updateGutter(); $('codeEditor').focus(); $('fileTree').innerHTML = renderTree(); document.querySelectorAll('.tree-file').forEach(button => button.addEventListener('click', () => openFile(button.dataset.file)));
  } catch (e) { toast(e.message, 'error'); }
}
function updateGutter() {
  const lines = $('codeEditor').value.split('\n').length;
  $('lineNumbers').innerHTML = Array.from({length: lines}, (_, i) => `<span>${i + 1}</span>`).join('');
  const el = $('codeEditor'); const before = el.value.slice(0, el.selectionStart); const line = before.split('\n').length; const col = before.length - before.lastIndexOf('\n'); $('cursorPos').textContent = `Ln ${line}, Col ${col}`;
}
async function saveCurrent() {
  if (!state.currentFile) return toast('Abra um arquivo para salvar.');
  try { await window.oficina.writeFile(state.currentFile, $('codeEditor').value); state.dirty = false; $('saveState').textContent = 'Salvo'; toast('Arquivo salvo.'); }
  catch (e) { toast(e.message, 'error'); }
}
async function newFile() {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  const name = prompt('Nome do arquivo (ex.: src/index.js):'); if (!name) return;
  try { const result = await window.oficina.newFile(name); await refreshTree(); await openFile(result.path); toast('Arquivo criado.'); }
  catch (e) { toast(e.message, 'error'); }
}
async function openWorkspace() {
  try { const result = await window.oficina.openWorkspace(); if (result) { state.currentFile = null; showWorkspace(result); $('welcome').classList.add('hidden'); $('editorWrap').classList.add('hidden'); $('tabs').innerHTML = '<div class="tab placeholder-tab">Projeto aberto</div>'; toast('Pasta aberta.'); } }
  catch (e) { toast(e.message, 'error'); }
}

async function checkOllama() {
  const status = await window.oficina.ollamaStatus(); state.ollamaReady = status.ok;
  const el = $('modelStatus');
  if (!status.ok) {
    el.innerHTML = '<span class="status-dot offline"></span><span>Ollama desconectado</span>';
    $('modelName').textContent = 'conectar';
    return status;
  }
  el.innerHTML = '<span class="status-dot"></span><span>Ollama conectado</span>';
  if (status.models.length) {
    state.model = state.model && status.models.includes(state.model) ? state.model : status.models[0];
    $('modelName').textContent = state.model;
  } else { state.model = null; $('modelName').textContent = 'sem modelo'; }
  return status;
}
async function showModelDialog() {
  $('modelDialog').classList.remove('hidden'); $('pullStatus').textContent = '';
  const status = await checkOllama();
  $('ollamaMissing').classList.toggle('hidden', status.ok);
  $('modelList').innerHTML = status.ok ? (status.models.length ? status.models.map(m => `<button class="model-option ${state.model === m ? 'chosen' : ''}" data-model="${escapeHtml(m)}"><span class="model-radio">${state.model === m ? '●' : '○'}</span><span><b>${escapeHtml(m)}</b><small>Disponível neste computador</small></span><span class="model-check">${state.model === m ? 'Selecionado' : ''}</span></button>`).join('') : '<div class="no-models">Ollama está ativo, mas nenhum modelo foi baixado.</div>') : '';
  document.querySelectorAll('.model-option').forEach(btn => btn.addEventListener('click', () => { state.model = btn.dataset.model; $('modelName').textContent = state.model; showModelDialog(); }));
}
async function generate() {
  const prompt = $('promptInput').value.trim();
  if (!prompt) return toast('Descreva o sistema ou código que quer criar.');
  if (!state.workspace) return toast('Abra ou crie uma pasta de projeto primeiro.');
  if (!state.ollamaReady || !state.model) { await showModelDialog(); return toast('Conecte o Ollama e selecione um modelo.'); }
  if (state.busy) return;
  state.busy = true; $('generateButton').disabled = true; $('generationState').classList.remove('hidden'); $('proposal').classList.add('hidden');
  try {
    let context = await window.oficina.projectContext();
    if (state.currentFile && state.dirty) context += `\n--- ${state.currentFile} (edição atual, ainda não salva) ---\n${$('codeEditor').value.slice(0, 5000)}`;
    const result = await window.oficina.generate({ model: state.model, prompt, context });
    if (!result.files.length) throw new Error('O modelo não gerou arquivos. Tente detalhar mais o pedido.');
    state.proposal = result;
    $('proposalSummary').textContent = result.summary;
    $('proposalFiles').innerHTML = result.files.map(f => `<div class="proposal-file"><span class="file-icon">${escapeHtml(iconFor(f.path))}</span><span>${escapeHtml(f.path)}</span>${getFiles().includes(f.path) ? '<em>substituir</em>' : ''}</div>`).join('');
    const preview = (file) => { $('proposalPreview').textContent = `// ${file.path}\n${file.content.slice(0, 6000)}${file.content.length > 6000 ? '\n… prévia limitada a 6.000 caracteres …' : ''}`; };
    preview(result.files[0]);
    document.querySelectorAll('.proposal-file').forEach((row, index) => row.addEventListener('click', () => preview(result.files[index])));
    $('proposal').classList.remove('hidden');
  } catch (e) { toast(e.message || 'Erro ao falar com o Ollama.', 'error'); }
  finally { state.busy = false; $('generateButton').disabled = false; $('generationState').classList.add('hidden'); }
}
async function applyProposal() {
  if (!state.proposal) return;
  if (state.dirty && state.currentFile && state.proposal.files.some(f => f.path === state.currentFile)) {
    if (!confirm(`Salvar as alterações atuais em ${state.currentFile} antes de aplicar a proposta?`)) return;
    try { await window.oficina.writeFile(state.currentFile, $('codeEditor').value); state.dirty = false; $('saveState').textContent = 'Salvo'; }
    catch (e) { return toast(e.message, 'error'); }
  }
  const replacing = state.proposal.files.filter(f => getFiles().includes(f.path)).length;
  const msg = replacing ? `A IA preparou ${state.proposal.files.length} arquivo(s), incluindo ${replacing} substituição(ões). Arquivos substituídos serão copiados em .oficina-backups. Aplicar?` : `Criar ${state.proposal.files.length} arquivo(s) na pasta do projeto?`;
  if (!confirm(msg)) return;
  try {
    const result = await window.oficina.applyGeneratedFiles(state.proposal.files);
    state.proposal = null; $('proposal').classList.add('hidden');
    const refreshed = await window.oficina.refreshWorkspace(); showWorkspace(refreshed);
    if (result.written.length) await openFile(result.written[0]);
    toast(`${result.written.length} arquivo(s) criado(s)/atualizado(s).`);
  } catch (e) { toast(e.message, 'error'); }
}

$('openFolder').addEventListener('click', openWorkspace); $('openFolderEmpty').addEventListener('click', openWorkspace); $('welcomeOpen').addEventListener('click', openWorkspace);
$('welcomeGenerate').addEventListener('click', () => { $('promptInput').focus(); $('promptInput').value = 'Crie um projeto inicial de site, com estrutura organizada, design responsivo e instruções de como executar.'; $('promptCount').textContent = `${$('promptInput').value.length} / 12.000`; });
$('newFile').addEventListener('click', newFile); $('newFileSide').addEventListener('click', newFile); $('refreshTree').addEventListener('click', refreshTree); $('refreshTreeSide').addEventListener('click', refreshTree); $('saveFile').addEventListener('click', saveCurrent);
$('codeEditor').addEventListener('input', () => { state.dirty = true; $('saveState').textContent = 'Não salvo'; updateGutter(); }); $('codeEditor').addEventListener('click', updateGutter); $('codeEditor').addEventListener('keyup', updateGutter); $('codeEditor').addEventListener('scroll', () => { $('lineNumbers').scrollTop = $('codeEditor').scrollTop; });
$('codeEditor').addEventListener('keydown', e => { if (e.key === 'Tab') { e.preventDefault(); const s = e.target.selectionStart, end = e.target.selectionEnd; e.target.setRangeText('  ', s, end, 'end'); e.target.dispatchEvent(new Event('input')); } });
$('modelMenu').addEventListener('click', showModelDialog); $('modelHelp').addEventListener('click', showModelDialog); $('closeModelDialog').addEventListener('click', () => $('modelDialog').classList.add('hidden')); $('modelDialog').addEventListener('click', e => { if (e.target === $('modelDialog')) $('modelDialog').classList.add('hidden'); });
$('installOllama').addEventListener('click', async () => { await window.oficina.openOllamaDownload(); }); $('pullModel').addEventListener('click', async () => {
  if (!state.ollamaReady) return toast('Instale e abra o Ollama primeiro.');
  const model = $('modelToInstall').value; $('pullModel').disabled = true; $('pullStatus').textContent = 'Preparando download…';
  try { await window.oficina.pullModel(model); state.model = model; $('modelName').textContent = model; $('pullStatus').textContent = 'Modelo pronto para usar.'; await checkOllama(); await showModelDialog(); }
  catch (e) { $('pullStatus').textContent = e.message; toast(e.message, 'error'); }
  finally { $('pullModel').disabled = false; }
});
window.oficina.onPullProgress(data => { $('pullStatus').textContent = data.percent == null ? data.status : `${data.status} · ${data.percent}%`; });
$('generateButton').addEventListener('click', generate); $('applyProposal').addEventListener('click', applyProposal); $('discardProposal').addEventListener('click', () => { state.proposal = null; $('proposal').classList.add('hidden'); }); $('clearPrompt').addEventListener('click', () => { $('promptInput').value = ''; $('promptCount').textContent = '0 / 12.000'; });
$('promptInput').addEventListener('input', () => { if ($('promptInput').value.length > 12000) $('promptInput').value = $('promptInput').value.slice(0, 12000); $('promptCount').textContent = `${$('promptInput').value.length.toLocaleString('pt-BR')} / 12.000`; });
$('commandForm').addEventListener('submit', async e => { e.preventDefault(); if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.'); const command = $('commandInput').value.trim(); if (!command) return; $('commandInput').value = ''; $('stopCommand').classList.remove('hidden'); try { await window.oficina.runCommand(command); } catch (e) { toast(e.message, 'error'); } finally { $('stopCommand').classList.add('hidden'); } });
window.oficina.onTerminalData(data => { const out = $('terminalContent'); out.textContent += data; out.scrollTop = out.scrollHeight; }); window.oficina.onTerminalDone(result => { $('terminalContent').textContent += `\r\n[processo finalizado · código ${result.code}]\r\n`; $('terminalContent').scrollTop = $('terminalContent').scrollHeight; });
$('stopCommand').addEventListener('click', () => window.oficina.stopCommand()); $('clearTerminal').addEventListener('click', () => { $('terminalContent').textContent = ''; }); $('toggleTerminal').addEventListener('click', () => $('terminalPanel').classList.toggle('collapsed'));
$('promptInput').addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') generate(); }); document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveCurrent(); } });

checkOllama().then(status => {
  if (!status.ok) { setStatus('Ollama não conectado — configure para começar'); showModelDialog(); }
  else if (!status.models.length) { setStatus('Ollama ativo — instale um modelo para começar'); showModelDialog(); }
  else setStatus('Ollama ativo · ' + status.models.length + ' modelo(s)');
});
