const test = require('node:test');
const assert = require('node:assert/strict');
const { flattenFilePaths } = require('../tree-utils');

test('flattenFilePaths coleta arquivos na raiz e em pastas aninhadas', () => {
  const tree = [
    { type: 'file', path: 'index.html' },
    { type: 'folder', path: 'src', children: [
      { type: 'file', path: 'src/app.js' },
      { type: 'folder', path: 'src/views', children: [
        { type: 'file', path: 'src/views/home.html' }
      ] }
    ] }
  ];
  assert.deepEqual(flattenFilePaths(tree), ['index.html', 'src/app.js', 'src/views/home.html']);
});

test('flattenFilePaths tolera lista vazia, children ausente e entradas inválidas', () => {
  assert.deepEqual(flattenFilePaths([]), []);
  assert.deepEqual(flattenFilePaths(null), []);
  assert.deepEqual(flattenFilePaths([
    null,
    { type: 'folder', path: 'empty' },
    { type: 'other', path: 'ignored' },
    { type: 'file' }
  ]), []);
});
