#!/bin/bash
cd "$(dirname "$0")"
exec ./iniciar-linux.sh
