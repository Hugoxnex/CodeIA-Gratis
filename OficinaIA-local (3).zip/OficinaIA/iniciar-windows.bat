@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js nao encontrado. Instale a versao LTS em https://nodejs.org/ && pause && exit /b 1)
if exist node_modules\electron goto start_app
echo Instalando dependencias gratuitas do aplicativo...
call npm install
if errorlevel 1 (echo Falha ao instalar dependencias. Verifique a internet e tente npm install. & pause & exit /b 1)
:start_app
echo Dependencias prontas.
npm start
if errorlevel 1 pause
