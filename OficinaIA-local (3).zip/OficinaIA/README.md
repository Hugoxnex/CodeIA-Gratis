# Oficina IA — editor local para programar com Ollama

Aplicativo desktop gratuito, com interface escura inspirada em editores de código. Você descreve em português o que quer criar; o modelo local prepara os arquivos, que só são gravados depois da sua confirmação.

## O que já funciona

- Interface desktop em português, com explorador de projeto, editor, abas, numeração de linhas e terminal.
- Conexão **local** com a API do Ollama em `127.0.0.1:11434`; seus pedidos e arquivos não são enviados a uma API de IA na nuvem.
- O app verifica o Ollama ao abrir e lista os modelos já instalados.
- Pode baixar modelos pelo próprio Ollama, incluindo `qwen2.5-coder:7b` (4,7 GB), `qwen2.5-coder:3b` e `qwen2.5-coder:14b`.
- Geração de um conjunto de arquivos a partir de um pedido em linguagem natural. Antes de gravá-los, mostra a lista e pede confirmação.
- Cópia de segurança automática de arquivos que serão substituídos, dentro de `.oficina-backups/` na pasta do projeto.
- Editor com salvamento `Ctrl+S` / `⌘S` e terminal que executa um comando por vez, somente quando você clica em **Executar**.
- Sem conta, chave de API, assinatura ou cobrança do aplicativo. Modelos são gratuitos e baixados para o seu computador.

## Requisitos

- Windows 10+, macOS 14+ ou Linux x64/arm64.
- Node.js 20 ou mais recente (inclui `npm`). Baixe gratuitamente em [nodejs.org](https://nodejs.org/).
- Ollama instalado localmente para usar geração por IA. Baixe gratuitamente em [ollama.com/download](https://ollama.com/download).
- Espaço em disco para o modelo escolhido; o modelo 7B recomendado ocupa aproximadamente 4,7 GB. O desempenho depende da memória e do processador/GPU disponíveis.

## Primeira execução

### Windows

1. Instale o Node.js LTS e o Ollama pelos sites oficiais acima.
2. Abra o Ollama uma vez e aguarde ele iniciar.
3. Extraia este ZIP para uma pasta comum (por exemplo, `Documentos`).
4. Dê dois cliques em `iniciar-windows.bat`. Na primeira vez, ele baixará as dependências gratuitas do Electron; precisa de internet.
5. No app, clique em **Modelo** → **Baixar** para obter um modelo de código, ou escolha um modelo que já esteja instalado.
6. Clique em **Abrir pasta**, selecione uma pasta de projeto e escreva sua ideia no painel **Assistente**.
7. Revise os arquivos propostos e clique em **Aplicar ao projeto**. Os arquivos existentes são guardados em `.oficina-backups/` antes de serem substituídos.

### macOS

Instale Node.js e Ollama; abra o Ollama. No Terminal, entre na pasta extraída e rode:

```bash
chmod +x iniciar-macos.command iniciar-linux.sh
./iniciar-macos.command
```

Se o macOS bloquear o arquivo baixado, abra o Terminal, navegue até a pasta e execute o comando acima.

### Linux

Instale Node.js e Ollama, confirme que `ollama serve` está ativo (ou que o serviço Ollama iniciou) e rode:

```bash
chmod +x iniciar-linux.sh
./iniciar-linux.sh
```

### Execução manual (qualquer sistema)

```bash
npm install
npm start
```

## Se o Ollama não estiver instalado

Ao iniciar, o Oficina IA verifica a API local. Se não encontrar Ollama, abra **Modelo** e use **Abrir instalação oficial**. O instalador oficial pode solicitar sua autorização do sistema operacional; após instalar e abrir o Ollama, volte ao Oficina IA. O aplicativo não instala software de sistema silenciosamente nem solicita privilégios de administrador sem você.

## Uso do modelo

- **Qwen2.5-Coder 7B** é a escolha inicial equilibrada para gerar e corrigir código; o catálogo oficial do Ollama lista um download de aproximadamente 4,7 GB. Escolha 3B se precisar de um modelo menor; 14B se o computador tiver mais memória.
- Para instalar manualmente, também funciona: `ollama pull qwen2.5-coder:7b`.
- Modelos locais são gratuitos, mas podem usar bastante memória e armazenamento. A velocidade depende do seu hardware; este projeto não mede a memória disponível nem promete desempenho idêntico em todos os computadores.

## Segurança e limites

- A geração **não grava nem executa código automaticamente**. Você revisa a proposta e confirma a gravação; substituições geram cópias em `.oficina-backups/`.
- O terminal executa comandos no projeto somente após seu clique. Comandos são iniciados sem shell e operadores de encadeamento (`&&`, `|`, `;`, redirecionamento) são bloqueados; ainda assim, um comando que você autorizar pode alterar arquivos do projeto ou do sistema. Execute apenas código e comandos que você entenda/confie.
- O projeto escolhido é o limite do editor para abrir e gravar arquivos. A árvore ignora pastas pesadas ou internas como `node_modules`, `.git` e `.oficina-backups`.
- O editor atual suporta arquivos de texto de até 2 MB. Este MVP não inclui extensões do VS Code, depurador visual, reconhecimento de voz, instalador nativo assinado, nem acesso autônomo ilimitado ao computador.
- Na primeira execução, `npm install` baixa Electron e dependências públicas; depois, geração de texto é local, mas downloads de modelos precisam de internet.

## Comparação de formatos

| Abordagem | Vantagens e limites | Custo | Configuração |
| --- | --- | --- | --- |
| Aplicativo desktop deste projeto | Acessa uma pasta local e chama diretamente o Ollama; exige Node.js para a primeira instalação das dependências. | Gratuito; espaço para o aplicativo e modelos. | Baixa a pasta/ZIP, instala Node.js e inicia. |
| Página local no navegador | Menos arquivos de instalação e abre no navegador; permissões do navegador tornam acesso a arquivos e execução de programas mais restritos. | Gratuito; ainda precisa Ollama. | Abre uma página e autoriza o acesso ao projeto. |

Este repositório implementa o formato desktop solicitado; a opção do navegador fica apenas como alternativa caso você prefira menos configuração local.

## Fontes oficiais

- [Ollama — downloads](https://ollama.com/download)
- [Ollama — Qwen2.5-Coder 7B e licença Apache 2.0](https://ollama.com/library/qwen2.5-coder:7b)
- [Electron](https://www.electronjs.org/)
