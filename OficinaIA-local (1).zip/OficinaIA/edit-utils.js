function applyExactEdits(content, edits) {
  if (!Array.isArray(edits) || edits.length === 0 || edits.length > 100) {
    throw new Error('A lista de alterações de código está vazia ou excede o limite.');
  }
  const original = String(content);
  const eol = original.includes('\r\n') ? '\r\n' : '\n';
  let result = original.replace(/\r\n/g, '\n');

  for (const edit of edits) {
    if (!edit || typeof edit.find !== 'string' || typeof edit.replace !== 'string' || !edit.find.length) {
      throw new Error('Cada alteração precisa indicar um trecho exato a localizar e o novo conteúdo.');
    }
    if (Buffer.byteLength(edit.find, 'utf8') > 12000 || Buffer.byteLength(edit.replace, 'utf8') > 24000) {
      throw new Error('Um trecho da alteração excede o limite seguro de tamanho.');
    }
    const find = edit.find.replace(/\r\n/g, '\n');
    const replace = edit.replace.replace(/\r\n/g, '\n');
    let first = result.indexOf(find);
    if (first < 0) throw new Error('O trecho original não foi encontrado. O arquivo pode ter mudado; peça a alteração novamente.');
    if (result.indexOf(find, first + 1) >= 0) throw new Error('O trecho original aparece mais de uma vez; a alteração foi bloqueada para evitar editar o local errado.');
    result = result.slice(0, first) + replace + result.slice(first + find.length);
  }

  return eol === '\r\n' ? result.replace(/\n/g, '\r\n') : result;
}

function normalizeHistory(history) {
  if (!Array.isArray(history)) return [];
  return history
    .filter(item => item && typeof item === 'object' && ['user', 'assistant'].includes(item.role) && typeof item.content === 'string')
    .slice(-40)
    .map(item => {
      const entry = {
        role: item.role,
        content: item.content.slice(0, 12000),
        timestamp: typeof item.timestamp === 'string' ? item.timestamp.slice(0, 40) : new Date().toISOString()
      };
      if (Array.isArray(item.files)) entry.files = item.files.filter(f => typeof f === 'string' && f.length <= 240).slice(0, 30);
      if (Array.isArray(item.changes)) entry.changes = item.changes
        .filter(change => change && typeof change.path === 'string' && change.path.length <= 240)
        .slice(0, 20)
        .map(change => change.created === true
          ? { path: change.path, created: true, content: typeof change.content === 'string' ? change.content.slice(0, 1200) : '' }
          : { path: change.path, find: typeof change.find === 'string' ? change.find.slice(0, 1200) : '', replace: typeof change.replace === 'string' ? change.replace.slice(0, 1200) : '' });
      if (typeof item.backupId === 'string' && /^[A-Za-z0-9TZ-]{1,80}$/.test(item.backupId)) entry.backupId = item.backupId;
      if (item.undone === true) entry.undone = true;
      return entry;
    });
}

module.exports = { applyExactEdits, normalizeHistory };
