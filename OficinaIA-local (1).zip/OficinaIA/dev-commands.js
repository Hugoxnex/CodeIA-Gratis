(function attachDevCommands(root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.OFICINA_DEV_COMMANDS = api;
})(typeof window !== 'undefined' ? window : null, function makeDevCommands() {
  const PACKAGE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}(?:==[A-Za-z0-9][A-Za-z0-9.+_-]{0,39})?$/;

  function quotePath(value) {
    const text = String(value || '');
    if (!text || /[\r\n"'`;|&<>$]/.test(text)) throw new Error('O caminho contém caracteres não permitidos para este atalho.');
    return /\s/.test(text) ? `"${text}"` : text;
  }

  function tokenizeTerminalCommand(input) {
    const tokens = String(input || '').match(/(?:"[^"\\]*(?:\\.[^"\\]*)*"|'[^'\\]*(?:\\.[^'\\]*)*'|[^\s]+)/g) || [];
    return tokens.map(token => {
      if ((token.startsWith('"') && token.endsWith('"')) || (token.startsWith("'") && token.endsWith("'"))) return token.slice(1, -1);
      return token;
    });
  }

  function pythonSystem(platform) {
    return platform === 'win32' ? 'py -3' : 'python3';
  }

  function pythonVenv(platform) {
    return platform === 'win32' ? '.\\.venv\\Scripts\\python.exe' : './.venv/bin/python';
  }

  function createPythonVenv(platform) {
    return `${pythonSystem(platform)} -m venv .venv`;
  }

  function normalizePythonPackages(input) {
    const packages = String(input || '').split(/[\s,]+/).filter(Boolean);
    if (!packages.length || packages.length > 20 || packages.some(name => !PACKAGE.test(name))) {
      throw new Error('Digite de 1 a 20 nomes de pacotes, separados por espaço ou vírgula. Ex.: requests, flask==3.1.');
    }
    return [...new Set(packages)];
  }

  function installPythonPackages(platform, input) {
    const packages = normalizePythonPackages(input);
    return `${quotePath(pythonVenv(platform))} -m pip install ${packages.join(' ')}`;
  }

  function installPythonRequirements(platform) {
    return `${quotePath(pythonVenv(platform))} -m pip install -r requirements.txt`;
  }

  function installPythonTools(platform) {
    return `${quotePath(pythonVenv(platform))} -m pip install ruff black pytest mypy`;
  }

  function runPythonFile(platform, file, hasVenv = true) {
    const interpreter = hasVenv ? quotePath(pythonVenv(platform)) : pythonSystem(platform);
    return `${interpreter} ${quotePath(file)}`;
  }

  function installNodeTools() {
    return 'npm install --save-dev eslint prettier';
  }

  return {
    quotePath,
    tokenizeTerminalCommand,
    pythonSystem,
    pythonVenv,
    createPythonVenv,
    normalizePythonPackages,
    installPythonPackages,
    installPythonRequirements,
    installPythonTools,
    runPythonFile,
    installNodeTools
  };
});
