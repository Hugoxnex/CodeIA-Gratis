const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const Module = require('node:module');

function loadHandlers(projectRoot, userData) {
  const handlers = new Map();
  const fakeWindow = {
    webContents: { send() {} },
    loadFile() {},
    on() {},
    isDestroyed() { return false; }
  };
  class BrowserWindow {
    constructor() { return fakeWindow; }
    static getAllWindows() { return [fakeWindow]; }
  }
  const electron = {
    app: { whenReady: () => Promise.resolve(), on() {}, quit() {}, getVersion: () => 'test', getPath: () => userData },
    BrowserWindow,
    dialog: { showOpenDialog: async () => ({ canceled: false, filePaths: [projectRoot] }) },
    ipcMain: { handle: (name, fn) => handlers.set(name, fn) },
    shell: { openExternal: async () => {} }
  };
  const originalLoad = Module._load;
  Module._load = function(request, parent, isMain) {
    if (request === 'electron') return electron;
    return originalLoad.call(this, request, parent, isMain);
  };
  const mainPath = require.resolve('../main.js');
  delete require.cache[mainPath];
  try { require(mainPath); }
  finally { Module._load = originalLoad; }
  return async (name, ...args) => {
    const handler = handlers.get(name);
    assert.ok(handler, `handler ausente: ${name}`);
    return handler({}, ...args);
  };
}

test('histórico fica fora do projeto; patch é aplicado direto com backup e pode ser desfeito', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-edit-test-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  const userData = path.join(base, 'perfil-app');
  await fs.mkdir(path.join(project, 'src'), { recursive: true });
  const source = 'const titulo = "Antigo";\r\nconst mantem = true;\r\n';
  const target = path.join(project, 'src', 'app.js');
  await fs.writeFile(target, source);
  const invoke = loadHandlers(project, userData);
  await invoke('workspace:open');

  assert.deepEqual(await invoke('workspace:history:load'), []);
  await invoke('workspace:history:save', [
    { role: 'user', content: 'Troque apenas o título.' },
    { role: 'assistant', content: 'Título alterado.', files: ['src/app.js'] }
  ]);
  assert.equal((await invoke('workspace:history:load')).length, 2);
  assert.deepEqual(await fs.readdir(project), ['src']);

  const applied = await invoke('workspace:apply-edits', {
    summary: 'Atualizei só o título.',
    edits: [{ path: 'src/app.js', find: 'const titulo = "Antigo";', replace: 'const titulo = "Novo";' }],
    files: []
  });
  assert.deepEqual(applied.written, ['src/app.js']);
  assert.match(applied.backupId, /^\d{4}-\d{2}-\d{2}T/);
  assert.equal(await fs.readFile(target, 'utf8'), 'const titulo = "Novo";\r\nconst mantem = true;\r\n');
  await invoke('workspace:undo-edit', applied.backupId);
  assert.equal(await fs.readFile(target, 'utf8'), source);
  await assert.rejects(invoke('workspace:undo-edit', applied.backupId), /já foi desfeito/);
});

test('patch ambíguo e sobrescrita integral de arquivo existente são bloqueados sem alterar conteúdo', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-edit-guard-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  await fs.mkdir(project);
  const target = path.join(project, 'index.js');
  await fs.writeFile(target, 'repetido();\nrepetido();\n');
  const invoke = loadHandlers(project, path.join(base, 'perfil-app'));
  await invoke('workspace:open');
  await assert.rejects(invoke('workspace:apply-edits', { edits: [{ path: 'index.js', find: 'repetido();', replace: 'mudado();' }], files: [] }), /mais de uma vez/);
  await assert.rejects(invoke('workspace:apply-edits', { edits: [], files: [{ path: 'index.js', content: 'reescrito' }] }), /já existe/);
  assert.equal(await fs.readFile(target, 'utf8'), 'repetido();\nrepetido();\n');
});

test('arquivo novo é escrito diretamente e a operação de desfazer o remove', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-new-file-test-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  await fs.mkdir(project);
  const invoke = loadHandlers(project, path.join(base, 'perfil-app'));
  await invoke('workspace:open');
  const result = await invoke('workspace:apply-edits', { edits: [], files: [{ path: 'src/novo.js', content: 'console.log("olá");\n' }] });
  assert.equal(await fs.readFile(path.join(project, 'src', 'novo.js'), 'utf8'), 'console.log("olá");\n');
  const undone = await invoke('workspace:undo-edit', result.backupId);
  assert.deepEqual(undone.removed, ['src/novo.js']);
  await assert.rejects(fs.access(path.join(project, 'src', 'novo.js')));
});

test('geração Ollama envia histórico somente como contexto e aceita patches mínimos', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-ollama-prompt-test-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  await fs.mkdir(project);
  const invoke = loadHandlers(project, path.join(base, 'perfil-app'));
  await invoke('workspace:open');
  const originalFetch = global.fetch;
  let sent;
  global.fetch = async (url, options) => {
    assert.equal(url, 'http://127.0.0.1:11434/api/chat');
    sent = JSON.parse(options.body);
    return {
      ok: true,
      json: async () => ({ message: { content: JSON.stringify({ summary: 'Troquei somente a cor.', edits: [{ path: 'src/app.css', find: '.botao { color: blue; }', replace: '.botao { color: green; }' }], files: [] }) } })
    };
  };
  t.after(() => { global.fetch = originalFetch; });
  const result = await invoke('ollama:generate', {
    model: 'qwen2.5-coder:14b',
    prompt: 'Agora troque só a cor para verde.',
    context: '--- src/app.css ---\n.botao { color: blue; }',
    history: [{ role: 'user', content: 'Antes, crie um botão.' }, { role: 'assistant', content: 'O botão foi criado.' }]
  });
  assert.equal(result.edits[0].path, 'src/app.css');
  assert.equal(result.files.length, 0);
  const historyMessage = sent.messages.find(message => message.content.includes('HISTÓRICO ANTERIOR'));
  const currentMessage = sent.messages.at(-1).content;
  assert.ok(historyMessage.content.includes('Antes, crie um botão.'));
  assert.ok(currentMessage.includes('PEDIDO ATUAL'));
  assert.ok(currentMessage.includes('Agora troque só a cor para verde.'));
  assert.ok(sent.messages[0].content.includes('NUNCA devolva o arquivo inteiro'));
});

test('desfazer bloqueia reversão se o arquivo mudou depois da edição da IA', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-undo-conflict-test-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  await fs.mkdir(project);
  const target = path.join(project, 'app.js');
  await fs.writeFile(target, 'const valor = 1;\n');
  const invoke = loadHandlers(project, path.join(base, 'perfil-app'));
  await invoke('workspace:open');
  const result = await invoke('workspace:apply-edits', { edits: [{ path: 'app.js', find: 'const valor = 1;', replace: 'const valor = 2;' }], files: [] });
  await fs.writeFile(target, 'const valor = 3; // edição humana\n');
  await assert.rejects(invoke('workspace:undo-edit', result.backupId), /alterado depois da IA/);
  assert.equal(await fs.readFile(target, 'utf8'), 'const valor = 3; // edição humana\n');
});

test('workspace:dev-info detecta se .venv está ausente, incompleta ou pronta', async t => {
  const base = await fs.mkdtemp(path.join(os.tmpdir(), 'oficina-dev-info-test-'));
  t.after(() => fs.rm(base, { recursive: true, force: true }));
  const project = path.join(base, 'projeto');
  await fs.mkdir(project);
  const invoke = loadHandlers(project, path.join(base, 'perfil-app'));
  await invoke('workspace:open');
  assert.deepEqual(await invoke('workspace:dev-info'), { platform: process.platform, hasVenv: false, invalidVenv: false });
  const interpreter = path.join(project, '.venv', process.platform === 'win32' ? 'Scripts' : 'bin', process.platform === 'win32' ? 'python.exe' : 'python');
  await fs.mkdir(path.dirname(interpreter), { recursive: true });
  assert.equal((await invoke('workspace:dev-info')).invalidVenv, true);
  await fs.writeFile(interpreter, 'fake python executable for metadata test');
  assert.equal((await invoke('workspace:dev-info')).hasVenv, true);
});
