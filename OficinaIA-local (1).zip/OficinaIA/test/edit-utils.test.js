const test = require('node:test');
const assert = require('node:assert/strict');
const { applyExactEdits, normalizeHistory } = require('../edit-utils');

test('applyExactEdits substitui somente o trecho único solicitado', () => {
  const source = 'const title = "Oficina";\nconst color = "blue";\n';
  const next = applyExactEdits(source, [{ find: 'const color = "blue";', replace: 'const color = "purple";' }]);
  assert.equal(next, 'const title = "Oficina";\nconst color = "purple";\n');
});

test('applyExactEdits encontra trechos com CRLF sem converter o arquivo para LF', () => {
  const source = 'const a = 1;\r\nconst b = 2;\r\n';
  const next = applyExactEdits(source, [{ find: 'const b = 2;\n', replace: 'const b = 3;\n' }]);
  assert.equal(next, 'const a = 1;\r\nconst b = 3;\r\n');
});

test('applyExactEdits bloqueia trecho ausente, repetido ou vazio', () => {
  assert.throws(() => applyExactEdits('const a = 1;', [{ find: 'const b = 2;', replace: 'const b = 3;' }]), /não foi encontrado/);
  assert.throws(() => applyExactEdits('x();\nx();', [{ find: 'x();', replace: 'y();' }]), /mais de uma vez/);
  assert.throws(() => applyExactEdits('x();', [{ find: '', replace: 'y();' }]), /trecho exato/);
});

test('normalizeHistory mantém apenas mensagens válidas e limita tamanho/campos', () => {
  const input = [
    { role: 'system', content: 'descartar' },
    { role: 'user', content: 'a'.repeat(13000) },
    { role: 'assistant', content: 'Feito', files: ['src/a.js'], backupId: '../fora' }
  ];
  const history = normalizeHistory(input);
  assert.equal(history.length, 2);
  assert.equal(history[0].content.length, 12000);
  assert.equal(history[1].backupId, undefined);
  assert.deepEqual(history[1].files, ['src/a.js']);
});

test('normalizeHistory limita prévias de diff e preserva novos arquivos', () => {
  const [entry] = normalizeHistory([{ role: 'assistant', content: 'Atualizado.', changes: [
    { path: 'src/a.js', find: 'x'.repeat(1500), replace: 'y'.repeat(1500) },
    { path: 'src/novo.js', created: true, content: 'z'.repeat(1500) }
  ] }]);
  assert.equal(entry.changes[0].find.length, 1200);
  assert.equal(entry.changes[0].replace.length, 1200);
  assert.equal(entry.changes[1].created, true);
  assert.equal(entry.changes[1].content.length, 1200);
});
