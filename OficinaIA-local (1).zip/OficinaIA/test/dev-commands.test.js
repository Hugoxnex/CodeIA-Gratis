const test = require('node:test');
const assert = require('node:assert/strict');
const commands = require('../dev-commands');

test('gera comando .venv compatível com Windows, macOS e Linux', () => {
  assert.equal(commands.createPythonVenv('win32'), 'py -3 -m venv .venv');
  assert.equal(commands.createPythonVenv('linux'), 'python3 -m venv .venv');
  assert.equal(commands.createPythonVenv('darwin'), 'python3 -m venv .venv');
  assert.equal(commands.pythonVenv('win32'), '.\\.venv\\Scripts\\python.exe');
  assert.equal(commands.pythonVenv('linux'), './.venv/bin/python');
});

test('instala bibliotecas e ferramentas dentro do .venv, não globalmente', () => {
  assert.equal(commands.installPythonPackages('win32', 'requests, flask==3.1'), '.\\.venv\\Scripts\\python.exe -m pip install requests flask==3.1');
  assert.equal(commands.installPythonRequirements('linux'), './.venv/bin/python -m pip install -r requirements.txt');
  assert.equal(commands.installPythonTools('darwin'), './.venv/bin/python -m pip install ruff black pytest mypy');
  assert.equal(commands.installNodeTools(), 'npm install --save-dev eslint prettier');
});

test('valida e deduplica pacotes; rejeita shell injection e requisitos arbitrários', () => {
  assert.deepEqual(commands.normalizePythonPackages('requests, flask requests'), ['requests', 'flask']);
  assert.deepEqual(commands.normalizePythonPackages('numpy==2.1.0'), ['numpy==2.1.0']);
  assert.throws(() => commands.normalizePythonPackages('requests && del .'), /nomes de pacotes/);
  assert.throws(() => commands.normalizePythonPackages('-r requirements.txt'), /nomes de pacotes/);
  assert.throws(() => commands.normalizePythonPackages('x '.repeat(21)), /1 a 20/);
});

test('executa scripts com espaços no caminho e bloqueia metacaracteres no atalho', () => {
  assert.equal(commands.runPythonFile('linux', 'src/meu app.py', true), './.venv/bin/python "src/meu app.py"');
  assert.equal(commands.runPythonFile('win32', 'main.py', false), 'py -3 main.py');
  assert.throws(() => commands.runPythonFile('linux', 'bad.py; rm -rf .', true), /caracteres não permitidos/);
});

test('tokeniza aspas e caminhos Windows sem usar um shell', () => {
  assert.deepEqual(commands.tokenizeTerminalCommand('py -3 -m venv .venv'), ['py', '-3', '-m', 'venv', '.venv']);
  assert.deepEqual(commands.tokenizeTerminalCommand('.\\.venv\\Scripts\\python.exe -m pip install requests'), ['.\\.venv\\Scripts\\python.exe', '-m', 'pip', 'install', 'requests']);
  assert.deepEqual(commands.tokenizeTerminalCommand('./.venv/bin/python "src/meu app.py"'), ['./.venv/bin/python', 'src/meu app.py']);
  assert.deepEqual(commands.tokenizeTerminalCommand('npm install --save-dev eslint prettier'), ['npm', 'install', '--save-dev', 'eslint', 'prettier']);
});
