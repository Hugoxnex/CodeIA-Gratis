# Oficina IA — editor local com Ollama

Aplicativo desktop gratuito, com aparência inspirada em IDEs. Você conversa em português com um modelo local do Ollama; o histórico fica salvo por pasta e as alterações são aplicadas diretamente no projeto por trechos exatos, com backup e opção de desfazer.

## O que mudou nesta versão

- Lista dinamicamente os modelos que já estão instalados pelo Ollama.
- Catálogo para baixar opções locais de código, modelos Mistral e outros modelos disponíveis na biblioteca Ollama.
- Destaques indicam o perfil de cada modelo (código, leve, geral ou avançado), tamanho do download e notas de licença/hardware.
- Permite colar uma tag publicada no Ollama para baixar modelos além dos destaques.
- Exibe o Google Model Garden como **referência externa**. O Oficina IA não conecta ao Google Cloud nem envia pedidos para serviços remotos; a geração continua usando Ollama neste computador.
- Mantém o histórico de pedidos e respostas separado por pasta de projeto, guardado no perfil local do Oficina IA.
- Para arquivos existentes, pede ao modelo um patch `localizar/substituir` mínimo; só aplica se o trecho aparecer exatamente uma vez. Arquivos novos são criados sem sobrescrever arquivos existentes.
- Aplica a edição direto na pasta escolhida e guarda cópias em `.oficina-backups/`; o histórico oferece **Desfazer última alteração** e bloqueia a reversão se o arquivo já tiver sido alterado depois.

## Modelos destacados

Os tamanhos abaixo são os downloads das variantes quantizadas listadas pelo Ollama. **Não são requisitos de RAM/VRAM.** A execução exige memória adicional para pesos carregados, runtime e contexto, e a velocidade varia conforme computador, backend e configuração.

| Perfil no app | Modelo / tag Ollama | Tamanho do download | Observações |
| --- | --- | ---: | --- |
| Destaque para programação | [Qwen3-Coder 30B](https://ollama.com/library/qwen3-coder:30b) · `qwen3-coder:30b` | 19 GB | Especializado em código; exige bastante memória local. Licença Apache 2.0. |
| Código equilibrado | [Qwen2.5-Coder 7B](https://ollama.com/library/qwen2.5-coder:7b) · `qwen2.5-coder:7b` | 4,7 GB | Opção de código menor que os modelos 14B/30B. Licença Apache 2.0. |
| Leve para código | [IBM Granite Code 3B](https://ollama.com/library/granite-code:3b) · `granite-code:3b` | 2,0 GB | Geração, explicação e correção de código; Apache 2.0. |
| Geral + programação | [Mistral Nemo 12B](https://ollama.com/library/mistral-nemo:12b) · `mistral-nemo:12b` | 7,1 GB | Modelo geral com apoio à programação; Apache 2.0. |
| Código · MoE | [DeepSeek-Coder V2 16B](https://ollama.com/library/deepseek-coder-v2:16b) · `deepseek-coder-v2:16b` | 8,9 GB | Licença dos pesos tem termos próprios; confira antes de uso comercial. |
| Repositórios · Mistral | [Devstral Small 2 24B](https://ollama.com/library/devstral-small-2:24b) · `devstral-small-2:24b` | 15 GB | Modelo maior; o Ollama indica versão 0.13.3 ou posterior. Apache 2.0. |
| Alternativa pequena | [Qwen2.5-Coder 3B](https://ollama.com/library/qwen2.5-coder:3b) · `qwen2.5-coder:3b` | 1,9 GB | A ficha do Ollama identifica **Qwen Research License Agreement**. Leia os termos; não o trate como liberado para uso comercial. Granite Code 3B é a opção compacta Apache 2.0. |

A lista traz modelos de famílias diferentes; não promete uma classificação universal nem desempenho igual em todos os computadores. O app não executa comandos sugeridos pelo modelo por conta própria: ele envia pedido, histórico e contexto ao Ollama local e grava apenas patches validados ou arquivos novos.

**Codestral não está entre os destaques para download:** a ficha do Ollama informa Mistral AI Non-Production License; uso comercial requer licença adicional. É possível inserir uma tag manualmente, mas confira os termos do modelo antes de usar.

## Requisitos

- Windows 10+, macOS 14+ ou Linux x64/arm64.
- Node.js 20 ou mais recente (inclui `npm`). Baixe gratuitamente em [nodejs.org](https://nodejs.org/).
- Ollama instalado localmente. Baixe gratuitamente em [ollama.com/download](https://ollama.com/download).
- Python 3.10+ é opcional para o app e necessário para usar o botão `.venv` e os comandos de Python. Instale gratuitamente em [python.org](https://www.python.org/downloads/).
- Internet para baixar o Electron na primeira execução e os modelos escolhidos.
- Espaço em disco e memória compatíveis com o modelo. O app mostra o tamanho do download, mas não calcula a memória disponível no seu computador.

## Primeira execução

### Windows

1. Instale Node.js LTS e Ollama pelos sites oficiais acima.
2. Abra o Ollama e aguarde iniciar.
3. Extraia o ZIP para uma pasta (por exemplo, Documentos).
4. Abra `iniciar-windows.bat`. Na primeira vez, ele baixa as dependências gratuitas do Electron.
5. No app, abra **Modelo**. Baixe um destaque ou selecione uma tag já instalada.
6. Clique em **Abrir pasta**, selecione uma pasta de projeto e escreva sua ideia no painel **Assistente**.
7. Descreva a alteração no painel **Assistente**. Ela será gravada direto na pasta; use **Desfazer última alteração** no histórico se precisar reverter.

## Terminal e ambientes do projeto

O terminal tem comandos rápidos para Python, Node.js, Git e compiladores, histórico de comandos com as setas **↑/↓**, limpeza com **Ctrl+L**, redimensionamento arrastando a borda superior e opção de maximizar. Cada atalho **preenche** a linha de comando; confira o comando e pressione **Enter** para executá-lo. Nada instala nem roda automaticamente ao abrir o projeto.

### Python: criar `.venv` e instalar bibliotecas

1. Abra a pasta do projeto e clique em **Criar .venv**. O app preenche `py -3 -m venv .venv` no Windows ou `python3 -m venv .venv` no macOS/Linux; pressione Enter. Se o Windows não reconhecer `py`, troque no campo por `python -m venv .venv`.
2. Aguarde o status **Python · .venv pronta**.
3. Clique em **+ Biblioteca Python**, informe nomes como `requests, flask==3.1` e execute o comando preenchido. A instalação usa o Python dentro de `.venv`, não o Python global.
4. Se o projeto trouxer `requirements.txt`, use **Comandos rápidos → Python → Instalar requirements.txt**. **Ferramentas Python** instala `ruff`, `black`, `pytest` e `mypy` dentro da `.venv`.
5. Abra um `.py` e selecione **Executar arquivo Python aberto** para executá-lo com o interpretador local do ambiente, quando disponível.

### Node.js e compiladores

- Em projetos com `package.json`, use **npm install**, **npm start** ou **Ferramentas Node** (ESLint + Prettier como dependências de desenvolvimento do projeto).
- O menu mostra exemplos `g++ main.cpp -o programa`, `javac Main.java`, `go build .` e `cargo build`. Esses exemplos precisam do compilador/toolchain correspondente já instalado no computador; o Oficina IA não baixa compiladores por conta própria.

O executor inicia **um processo por comando**, dentro da raiz do projeto, sem operadores de shell como `&&`, `|` ou redirecionamentos. Por isso, para criar o ambiente e depois instalar pacotes, execute cada comando separadamente. A saída é local e o botão **Parar** interrompe um processo em andamento.

## Extensões do VS Code

Esta aplicação ainda não carrega extensões `.vsix` nem implementa o host de extensões, depurador ou terminal PTY interativo do VS Code. Os atalhos acima instalam **pacotes e ferramentas do próprio projeto** (por exemplo, bibliotecas Python ou ESLint/Prettier), que são diferentes de extensões do marketplace. A interface é inspirada em uma IDE, não é um clone compatível com o VS Code.

### macOS

Instale Node.js e Ollama; abra Ollama. No Terminal, entre na pasta extraída e rode:

```bash
chmod +x iniciar-macos.command iniciar-linux.sh
./iniciar-macos.command
```

### Linux

Instale Node.js e Ollama, confirme que o serviço Ollama está ativo e rode:

```bash
chmod +x iniciar-linux.sh
./iniciar-linux.sh
```

### Execução manual

```bash
npm install
npm start
```

## Model Garden do Google

O link do [Google Model Garden](https://console.cloud.google.com/agent-platform/publishers/google/model-garden/364?hl=pt-br) aparece no diálogo de modelos apenas para consulta. **Não há integração com Vertex AI/Google Cloud nesta versão**, então não é possível escolher ou executar esses modelos hospedados dentro do Oficina IA.

## Opção Manus online

Esta versão ainda **não chama a API Manus** e não pede nem guarda credenciais Manus. A documentação oficial estabelece que:

- O login OAuth por Open App exige conta **Team**; contas pessoais não podem criar nem autorizar esses apps. Além disso, um Open App comum só pode ser autorizado por pessoas da mesma equipe; um app público confiável é disponibilizado apenas a parceiros aprovados. Portanto, a tela da captura — conta **Pessoal/Grátis** — não pode usar o fluxo de “entrar com Manus” pedido.
- Uma chave de API é uma alternativa técnica diferente do login: cada pessoa precisaria criar e guardar sua própria chave, que concede acesso amplo à conta. Ela não deve ser embutida num ZIP, enviada pelo chat ou compartilhada entre usuários.
- A documentação oferece APIs para consultar alterações de créditos, mas não permite afirmar aqui como as chamadas de uma integração de terceiros se relacionariam com o saldo mostrado na interface ou com o plano desta conta. Antes de ligar a API, confirme esse ponto em [help.manus.im](https://help.manus.im).

| Caminho | Vantagens e limitações | Custo/ créditos | Complexidade |
| --- | --- | --- | --- |
| Ollama local (já disponível) | Não exige conta Manus nem envia o projeto para a nuvem; depende do hardware e do modelo do computador. | Sem chamadas à API Manus; requer baixar modelos locais. | Baixa |
| Chave API individual | Pode chamar a API por conta, mas não oferece a tela de login solicitada e a chave dá acesso amplo; precisaria ser guardada com segurança no computador de cada usuário. | O tratamento do saldo da interface não está confirmado; consulte o suporte antes de usar. | Média/alta |
| Open App/OAuth | É o login adequado para um painel com autorização do usuário, mas a documentação limita a criação/autorização a Team e restringe usuários à mesma equipe; não atende a conta pessoal da captura. | A relação com os créditos do plano precisa ser confirmada com o suporte. | Alta |

## Segurança e limites

- Antes de pedir uma edição, o texto aberto no editor é salvo automaticamente para que o patch use a versão atual. Alterações da IA são aplicadas direto, como solicitado, mas cada patch precisa localizar um trecho único; ambiguidades ou tentativas de sobrescrever um arquivo existente por inteiro são bloqueadas.
- Cada edição direta gera backup em `.oficina-backups/`. O botão de desfazer só restaura arquivos que não mudaram depois da edição, evitando apagar alterações mais recentes.
- O terminal só roda um comando após Enter; executa processos locais com `shell: false`, bloqueia operadores de shell e não inicia código sozinho. Revise os comandos de instalação antes de confirmar.
- O editor trabalha dentro da pasta escolhida e suporta arquivos de texto de até 2 MB.
- A lista oficial de modelos Ollama pode mudar. O campo de tag manual aceita outras tags, mas a licença e as necessidades de hardware são específicas de cada modelo.
- Este é um MVP inspirado em IDEs: não é uma extensão oficial do VS Code, não carrega `.vsix` e não inclui depurador visual nem entrada por microfone.

## Testes do projeto

```bash
npm run check
npm test
```

## Fontes oficiais

- [Ollama — downloads](https://ollama.com/download)
- [Qwen3-Coder 30B](https://ollama.com/library/qwen3-coder:30b)
- [Qwen2.5-Coder 7B](https://ollama.com/library/qwen2.5-coder:7b)
- [Granite Code 3B](https://ollama.com/library/granite-code:3b)
- [Mistral Nemo 12B](https://ollama.com/library/mistral-nemo:12b)
- [Devstral Small 2 24B](https://ollama.com/library/devstral-small-2:24b)
- [DeepSeek-Coder V2 16B](https://ollama.com/library/deepseek-coder-v2:16b)
- [Google Model Garden](https://console.cloud.google.com/agent-platform/publishers/google/model-garden/364?hl=pt-br)
- [Manus API — Open App/OAuth](https://open.manus.ai/docs/v2/open-app)
- [Manus API — autenticação e chaves](https://open.manus.ai/docs/v2/authentication)
- [Manus API — histórico de alterações de créditos](https://open.manus.ai/docs/v2/usage.list)
- [Ajuda Manus](https://help.manus.im)
- [Electron](https://www.electronjs.org/)
