const $ = (id) => document.getElementById(id);
const state = { workspace: null, tree: [], currentFile: null, dirty: false, history: [], lastBackupId: null, model: null, ollamaReady: false, busy: false, undoBusy: false, devInfo: { platform: '', hasVenv: false, invalidVenv: false }, commandHistory: [], commandHistoryIndex: 0, terminalDrag: null };
const icons = { js: 'JS', jsx: 'JS', ts: 'TS', tsx: 'TS', html: '◇', css: '#', json: '{}', md: 'M↓', py: 'Py', sh: '$_', bat: '$_', yml: '⚙', yaml: '⚙', txt: '≡', default: '·' };
const MODEL_CATALOG = Array.isArray(window.MODEL_CATALOG) ? window.MODEL_CATALOG : [];

function toast(message, type = '') {
  const el = $('toast'); el.textContent = message; el.className = `toast ${type}`;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.add('hidden'), 3600);
}
function setStatus(message) { $('statusWorkspace').textContent = message; }
function extName(filename) { return (filename.split('.').pop() || 'txt').toLowerCase(); }
function iconFor(filename) { const ext = extName(filename); return icons[ext] || icons.default; }
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function getFiles(nodes = state.tree, result = []) { for (const n of nodes) { if (n.type === 'file') result.push(n.path); else getFiles(n.children || [], result); } return result; }

function renderTree(nodes = state.tree, depth = 0) {
  if (!nodes.length && depth === 0) return '<div class="tree-hint">Pasta vazia — crie um arquivo ou peça para a IA.</div>';
  return nodes.map(node => {
    const indent = `style="--depth:${depth}"`;
    if (node.type === 'folder') return `<div class="tree-folder" ${indent}><span class="folder-arrow">⌄</span><span class="folder-icon">▰</span><span>${escapeHtml(node.name)}</span></div>${renderTree(node.children || [], depth + 1)}`;
    return `<button class="tree-file ${state.currentFile === node.path ? 'selected' : ''}" data-file="${escapeHtml(node.path)}" ${indent}><span class="file-icon fi-${extName(node.name)}">${escapeHtml(iconFor(node.name))}</span><span>${escapeHtml(node.name)}</span></button>`;
  }).join('');
}
function showWorkspace(result) {
  if (!result) return;
  state.workspace = result.path; state.tree = result.tree || [];
  const name = result.path.split(/[\\/]/).filter(Boolean).pop() || result.path;
  $('workspaceName').textContent = name; $('projectLabel').textContent = name.toUpperCase(); $('statusWorkspace').textContent = result.path;
  $('fileTree').innerHTML = renderTree(); $('assistantContext').innerHTML = `<span class="context-dot ready"></span><span>Projeto aberto: ${escapeHtml(name)} · ${getFiles().length} arquivo(s)</span>`;
  document.querySelectorAll('.tree-file').forEach(button => button.addEventListener('click', () => openFile(button.dataset.file)));
  $('welcome').classList.add('hidden'); if (!state.currentFile) $('editorWrap').classList.add('hidden');
}
function renderHistory() {
  const list = $('assistantHistory');
  if (!list) return;
  const messages = state.history.slice(-30);
  const lastUndo = [...state.history].reverse().find(item => item.role === 'assistant' && item.backupId && !item.undone);
  state.lastBackupId = lastUndo?.backupId || null;
  $('historyCount').textContent = `${state.history.length} mensagem(ns)`;
  if (!messages.length) {
    list.innerHTML = '<div class="history-empty">Descreva uma ideia ou peça uma alteração. O histórico fica salvo localmente por pasta.</div>';
    return;
  }
  list.innerHTML = messages.map(message => {
    const changed = Array.isArray(message.files) && message.files.length ? `<div class="history-files">Arquivos: ${message.files.map(escapeHtml).join(', ')}</div>` : '';
    const diffs = Array.isArray(message.changes) ? message.changes.map(change => {
      const lines = change.created
        ? `+ ${change.content || ''}`
        : [...String(change.find || '').split('\n').map(line => `− ${line}`), ...String(change.replace || '').split('\n').map(line => `+ ${line}`)].join('\n');
      return `<details class="history-diff"><summary>${escapeHtml(change.path)}${change.created ? ' · arquivo novo' : ' · trecho alterado'}</summary><pre>${escapeHtml(lines)}</pre></details>`;
    }).join('') : '';
    const undo = message.backupId && !message.undone && message.backupId === state.lastBackupId ? `<button class="history-undo" data-backup="${escapeHtml(message.backupId)}" ${state.undoBusy ? 'disabled' : ''}>Desfazer última alteração</button>` : '';
    const undone = message.undone ? '<span class="history-undone">Desfeito</span>' : '';
    return `<article class="history-message ${message.role === 'user' ? 'from-user' : 'from-assistant'}"><div class="history-role">${message.role === 'user' ? 'Você' : 'Oficina IA'} <span>${escapeHtml(message.timestamp || '')}</span></div><div class="history-content">${escapeHtml(message.content || '').replace(/\n/g, '<br>')}</div>${changed}${diffs}${undone}${undo}</article>`;
  }).join('');
  list.querySelectorAll('.history-undo').forEach(button => button.addEventListener('click', () => undoLastChange(button.dataset.backup)));
  list.scrollTop = list.scrollHeight;
}
async function loadHistoryForWorkspace() {
  if (!state.workspace) return;
  try { state.history = await window.oficina.loadHistory(); renderHistory(); }
  catch (e) { state.history = []; renderHistory(); toast(`Não foi possível carregar o histórico: ${e.message}`, 'error'); }
}
async function persistHistory() {
  if (!state.workspace) return;
  state.history = state.history.slice(-40);
  try { state.history = await window.oficina.saveHistory(state.history); renderHistory(); }
  catch (e) { toast(`Não foi possível salvar o histórico: ${e.message}`, 'error'); }
}
async function addHistoryMessage(message) {
  state.history.push({ ...message, timestamp: new Date().toISOString() });
  await persistHistory();
}
async function undoLastChange(backupId = state.lastBackupId) {
  if (!backupId || state.undoBusy) return;
  state.undoBusy = true; renderHistory();
  try {
    if (state.dirty && state.currentFile) {
      await window.oficina.writeFile(state.currentFile, $('codeEditor').value);
      state.dirty = false; $('saveState').textContent = 'Salvo';
    }
    const result = await window.oficina.undoEdit(backupId);
    const entry = [...state.history].reverse().find(item => item.backupId === backupId);
    if (entry) entry.undone = true;
    const changed = [...result.restored, ...result.removed];
    await addHistoryMessage({ role: 'assistant', content: `Desfiz a última alteração. ${changed.length} arquivo(s) restaurado(s) ou removido(s).`, files: changed });
    const current = state.currentFile;
    showWorkspace(await window.oficina.refreshWorkspace());
    if (current && changed.includes(current)) {
      if (result.removed.includes(current)) {
        state.currentFile = null; $('editorWrap').classList.add('hidden'); $('welcome').classList.remove('hidden'); $('tabs').innerHTML = '<div class="tab placeholder-tab">Bem-vindo</div>';
      } else await openFile(current);
    }
    toast('Última alteração desfeita; o backup continua guardado.');
  } catch (e) { toast(e.message, 'error'); }
  finally { state.undoBusy = false; renderHistory(); }
}
async function refreshTree() {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  try { showWorkspace(await window.oficina.refreshWorkspace()); await refreshDevInfo(); } catch (e) { toast(e.message, 'error'); }
}
async function openFile(relative) {
  if (state.dirty && !confirm('Há alterações não salvas. Abrir outro arquivo sem salvar?')) return;
  try {
    const file = await window.oficina.readFile(relative); state.currentFile = file.path; state.dirty = false;
    $('codeEditor').value = file.content; $('filePathLabel').textContent = file.path; $('saveState').textContent = 'Salvo';
    $('editorWrap').classList.remove('hidden'); $('welcome').classList.add('hidden'); $('languageLabel').textContent = extName(file.path);
    $('tabs').innerHTML = `<div class="tab active"><span class="tab-file-icon">${escapeHtml(iconFor(file.path))}</span>${escapeHtml(file.path.split('/').pop())}<button id="tabClose" class="tab-close">×</button></div>`;
    $('tabClose').addEventListener('click', () => { state.currentFile = null; $('editorWrap').classList.add('hidden'); $('welcome').classList.remove('hidden'); $('tabs').innerHTML = '<div class="tab placeholder-tab">Bem-vindo</div>'; });
    updateGutter(); $('codeEditor').focus(); $('fileTree').innerHTML = renderTree(); document.querySelectorAll('.tree-file').forEach(button => button.addEventListener('click', () => openFile(button.dataset.file)));
  } catch (e) { toast(e.message, 'error'); }
}
function updateGutter() {
  const lines = $('codeEditor').value.split('\n').length;
  $('lineNumbers').innerHTML = Array.from({length: lines}, (_, i) => `<span>${i + 1}</span>`).join('');
  const el = $('codeEditor'); const before = el.value.slice(0, el.selectionStart); const line = before.split('\n').length; const col = before.length - before.lastIndexOf('\n'); $('cursorPos').textContent = `Ln ${line}, Col ${col}`;
}
async function saveCurrent() {
  if (!state.currentFile) return toast('Abra um arquivo para salvar.');
  try { await window.oficina.writeFile(state.currentFile, $('codeEditor').value); state.dirty = false; $('saveState').textContent = 'Salvo'; toast('Arquivo salvo.'); }
  catch (e) { toast(e.message, 'error'); }
}
async function newFile() {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  const name = prompt('Nome do arquivo (ex.: src/index.js):'); if (!name) return;
  try { const result = await window.oficina.newFile(name); await refreshTree(); await openFile(result.path); toast('Arquivo criado.'); }
  catch (e) { toast(e.message, 'error'); }
}
async function openWorkspace() {
  try { const result = await window.oficina.openWorkspace(); if (result) { state.currentFile = null; state.history = []; state.lastBackupId = null; showWorkspace(result); $('welcome').classList.add('hidden'); $('editorWrap').classList.add('hidden'); $('tabs').innerHTML = '<div class="tab placeholder-tab">Projeto aberto</div>'; await loadHistoryForWorkspace(); await refreshDevInfo(); toast('Pasta aberta. Histórico local carregado.'); } }
  catch (e) { toast(e.message, 'error'); }
}

async function refreshDevInfo() {
  const label = $('pythonEnvStatus');
  if (!state.workspace || !label) return;
  try {
    state.devInfo = await window.oficina.devInfo();
    if (state.devInfo.hasVenv) {
      label.textContent = 'Python · .venv pronta'; label.className = 'environment-status ready';
    } else if (state.devInfo.invalidVenv) {
      label.textContent = 'Python · .venv incompleta'; label.className = 'environment-status warning';
    } else {
      label.textContent = 'Python · sem ambiente virtual'; label.className = 'environment-status';
    }
  } catch (e) { label.textContent = 'Python · não detectado'; label.className = 'environment-status warning'; }
}

function fillTerminalCommand(command) {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  if (!command) return;
  $('terminalPanel').classList.remove('collapsed', 'maximized');
  $('toggleTerminalMax').textContent = '□'; $('toggleTerminalMax').title = 'Maximizar terminal';
  $('commandInput').value = command; $('commandInput').focus(); $('commandInput').setSelectionRange(command.length, command.length);
  toast('Comando preenchido. Confira-o e pressione Enter para executar.');
}

function hasRootFile(filename) { return state.tree.some(node => node.type === 'file' && node.name.toLowerCase() === filename.toLowerCase()); }

function selectQuickCommand(action) {
  const tools = window.OFICINA_DEV_COMMANDS;
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  const platform = state.devInfo.platform || 'linux';
  try {
    switch (action) {
      case 'python-venv':
        if (state.devInfo.hasVenv) return toast('O ambiente .venv já existe neste projeto.');
        if (state.devInfo.invalidVenv) return toast('A pasta .venv existe, mas está incompleta. Renomeie/remova-a manualmente antes de criar outra.', 'error');
        return fillTerminalCommand(tools.createPythonVenv(platform));
      case 'python-run-current':
        if (!state.currentFile || !state.currentFile.toLowerCase().endsWith('.py')) return toast('Abra um arquivo .py primeiro.');
        return fillTerminalCommand(tools.runPythonFile(platform, state.currentFile, state.devInfo.hasVenv));
      case 'python-requirements':
        if (!state.devInfo.hasVenv) return toast('Crie .venv primeiro para instalar bibliotecas dentro do projeto.');
        if (!hasRootFile('requirements.txt')) return toast('Este projeto não tem requirements.txt na pasta principal.');
        return fillTerminalCommand(tools.installPythonRequirements(platform));
      case 'python-tools':
        if (!state.devInfo.hasVenv) return toast('Crie .venv primeiro para manter as ferramentas isoladas no projeto.');
        return fillTerminalCommand(tools.installPythonTools(platform));
      case 'node-install':
        if (!hasRootFile('package.json')) return toast('Não encontrei package.json na pasta principal.');
        return fillTerminalCommand('npm install');
      case 'node-start':
        if (!hasRootFile('package.json')) return toast('Não encontrei package.json na pasta principal.');
        return fillTerminalCommand('npm start');
      case 'node-tools':
        if (!hasRootFile('package.json')) return toast('Crie ou abra um projeto Node com package.json primeiro.');
        return fillTerminalCommand(tools.installNodeTools());
      case 'compile-cpp': return fillTerminalCommand('g++ main.cpp -o programa');
      case 'compile-java': return fillTerminalCommand('javac Main.java');
      case 'build-go': return fillTerminalCommand('go build .');
      case 'build-rust': return fillTerminalCommand('cargo build');
      case 'git-status': return fillTerminalCommand('git status --short');
      default: return;
    }
  } catch (e) { toast(e.message, 'error'); }
}

function installPythonPackagesFromPrompt() {
  if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
  if (!state.devInfo.hasVenv) return toast('Crie .venv primeiro para manter a biblioteca dentro do projeto.');
  const input = prompt('Nome(s) das bibliotecas Python, separados por vírgula ou espaço. Ex.: requests, flask==3.1');
  if (input === null || !input.trim()) return;
  try { fillTerminalCommand(window.OFICINA_DEV_COMMANDS.installPythonPackages(state.devInfo.platform, input)); }
  catch (e) { toast(e.message, 'error'); }
}

async function checkOllama() {
  const status = await window.oficina.ollamaStatus(); state.ollamaReady = status.ok;
  const el = $('modelStatus');
  if (!status.ok) {
    el.innerHTML = '<span class="status-dot offline"></span><span>Ollama desconectado</span>';
    $('modelName').textContent = 'conectar';
    return status;
  }
  el.innerHTML = '<span class="status-dot"></span><span>Ollama conectado</span>';
  if (status.models.length) {
    state.model = state.model && status.models.includes(state.model) ? state.model : status.models[0];
    $('modelName').textContent = state.model;
  } else { state.model = null; $('modelName').textContent = 'sem modelo'; }
  return status;
}
async function showModelDialog() {
  $('modelDialog').classList.remove('hidden'); $('pullStatus').textContent = '';
  const status = await checkOllama();
  $('ollamaMissing').classList.toggle('hidden', status.ok);
  const installed = status.models || [];
  $('modelList').innerHTML = status.ok ? (installed.length ? installed.map(m => {
    const info = MODEL_CATALOG.find(item => item.tag === m);
    const description = info ? `${info.badge} · ${info.recommendation}` : 'Modelo local detectado pelo Ollama';
    return `<button class="model-option ${state.model === m ? 'chosen' : ''}" data-model="${escapeHtml(m)}"><span class="model-radio">${state.model === m ? '●' : '○'}</span><span><b>${escapeHtml(m)}</b><small>${escapeHtml(description)}</small></span><span class="model-check">${state.model === m ? 'Selecionado' : 'Usar'}</span></button>`;
  }).join('') : '<div class="no-models">Ollama está ativo, mas nenhum modelo foi baixado.</div>') : '<div class="no-models">Inicie o Ollama para listar modelos já instalados.</div>';
  document.querySelectorAll('.model-option').forEach(btn => btn.addEventListener('click', () => { state.model = btn.dataset.model; $('modelName').textContent = state.model; showModelDialog(); }));
  const groups = [...new Set(MODEL_CATALOG.map(item => item.group))];
  $('modelToInstall').innerHTML = groups.map(group => `<optgroup label="${escapeHtml(group)}">${MODEL_CATALOG.filter(item => item.group === group).map(item => `<option value="${escapeHtml(item.tag)}">${escapeHtml(item.name)} · ${escapeHtml(item.size)}</option>`).join('')}</optgroup>`).join('');
  const defaultModel = MODEL_CATALOG.some(item => item.tag === state.model) ? state.model : 'qwen2.5-coder:7b';
  if (MODEL_CATALOG.some(item => item.tag === defaultModel)) $('modelToInstall').value = defaultModel;
  $('modelCatalog').innerHTML = MODEL_CATALOG.map(item => {
    const present = installed.includes(item.tag);
    return `<article class="catalog-card ${item.featured ? 'featured' : ''}"><div class="catalog-card-head"><div><div class="catalog-card-title">${escapeHtml(item.name)}</div><div class="catalog-card-tag">${escapeHtml(item.tag)}</div></div><span class="catalog-badge">${escapeHtml(item.badge)}</span></div><div class="catalog-card-desc">${escapeHtml(item.description)}</div><div class="catalog-card-meta"><span>${escapeHtml(item.size)}</span><span>${escapeHtml(item.hardware)}</span></div><div class="catalog-card-actions"><button class="catalog-reference" data-url="${escapeHtml(item.url)}">Ficha oficial ↗</button><button class="catalog-card-action" data-model="${escapeHtml(item.tag)}" ${!status.ok ? 'disabled' : ''}>${present ? 'Usar modelo instalado' : (status.ok ? 'Baixar este modelo' : 'Requer Ollama')}</button></div></article>`;
  }).join('');
  document.querySelectorAll('.catalog-reference').forEach(btn => btn.addEventListener('click', () => window.oficina.openExternal(btn.dataset.url)));
  document.querySelectorAll('.catalog-card-action').forEach(btn => btn.addEventListener('click', async () => {
    const tag = btn.dataset.model;
    if (installed.includes(tag)) { state.model = tag; $('modelName').textContent = tag; await showModelDialog(); }
    else { $('modelToInstall').value = tag; await pullModelByTag(tag); }
  }));
}
async function pullModelByTag(model) {
  if (!state.ollamaReady) return toast('Instale e inicie o Ollama para baixar um modelo.');
  $('pullModel').disabled = true; $('pullStatus').textContent = `Preparando download de ${model}…`;
  try {
    await window.oficina.pullModel(model);
    state.model = model; $('modelName').textContent = model;
    await showModelDialog(); toast(`${model} foi baixado. Modelo selecionado.`);
  } catch (e) { $('pullStatus').textContent = e.message; toast(e.message, 'error'); }
  finally { $('pullModel').disabled = false; }
}
async function generate() {
  const prompt = $('promptInput').value.trim();
  if (!prompt) return toast('Descreva a mudança ou o sistema que quer criar.');
  if (!state.workspace) return toast('Abra ou crie uma pasta de projeto primeiro.');
  if (!state.ollamaReady || !state.model) { await showModelDialog(); return toast('Conecte o Ollama e selecione um modelo.'); }
  if (state.busy) return;
  state.busy = true; $('generateButton').disabled = true; $('generationState').classList.remove('hidden');
  try {
    if (state.dirty && state.currentFile) {
      await window.oficina.writeFile(state.currentFile, $('codeEditor').value);
      state.dirty = false; $('saveState').textContent = 'Salvo';
    }
    state.history.push({ role: 'user', content: prompt, timestamp: new Date().toISOString() });
    await persistHistory();
    const context = await window.oficina.projectContext();
    const result = await window.oficina.generate({ model: state.model, prompt, context, history: state.history.slice(0, -1) });
    const summary = result.summary || 'Resposta pronta.';
    const hasChanges = result.edits.length > 0 || result.files.length > 0;
    if (!hasChanges) {
      await addHistoryMessage({ role: 'assistant', content: summary });
      $('promptInput').value = ''; $('promptCount').textContent = '0 / 12.000';
      return;
    }

    const applied = await window.oficina.applyEdits(result);
    if (!applied.written.length) {
      await addHistoryMessage({ role: 'assistant', content: summary });
      $('promptInput').value = ''; $('promptCount').textContent = '0 / 12.000';
      return;
    }
    const changes = [
      ...result.edits.map(edit => ({ path: edit.path, find: edit.find, replace: edit.replace })),
      ...result.files.map(file => ({ path: file.path, created: true, content: file.content }))
    ];
    await addHistoryMessage({ role: 'assistant', content: summary, files: applied.written, changes, backupId: applied.backupId });
    const previouslyOpen = state.currentFile;
    showWorkspace(await window.oficina.refreshWorkspace());
    if (previouslyOpen && applied.written.includes(previouslyOpen)) await openFile(previouslyOpen);
    else if (!previouslyOpen && applied.written.length) await openFile(applied.written[0]);
    $('promptInput').value = ''; $('promptCount').textContent = '0 / 12.000';
    toast(`${applied.written.length} arquivo(s) alterado(s) direto no projeto; backup salvo. Você pode desfazer no histórico.`);
  } catch (e) {
    await addHistoryMessage({ role: 'assistant', content: `Não consegui aplicar essa alteração: ${e.message}` });
    toast(e.message || 'Erro ao falar com o Ollama.', 'error');
  }
  finally { state.busy = false; $('generateButton').disabled = false; $('generationState').classList.add('hidden'); }
}

$('openFolder').addEventListener('click', openWorkspace); $('openFolderEmpty').addEventListener('click', openWorkspace); $('welcomeOpen').addEventListener('click', openWorkspace);
$('welcomeGenerate').addEventListener('click', () => { $('promptInput').focus(); $('promptInput').value = 'Crie um projeto inicial de site, com estrutura organizada, design responsivo e instruções de como executar.'; $('promptCount').textContent = `${$('promptInput').value.length} / 12.000`; });
$('newFile').addEventListener('click', newFile); $('newFileSide').addEventListener('click', newFile); $('refreshTree').addEventListener('click', refreshTree); $('refreshTreeSide').addEventListener('click', refreshTree); $('saveFile').addEventListener('click', saveCurrent);
$('codeEditor').addEventListener('input', () => { state.dirty = true; $('saveState').textContent = 'Não salvo'; updateGutter(); }); $('codeEditor').addEventListener('click', updateGutter); $('codeEditor').addEventListener('keyup', updateGutter); $('codeEditor').addEventListener('scroll', () => { $('lineNumbers').scrollTop = $('codeEditor').scrollTop; });
$('codeEditor').addEventListener('keydown', e => { if (e.key === 'Tab') { e.preventDefault(); const s = e.target.selectionStart, end = e.target.selectionEnd; e.target.setRangeText('  ', s, end, 'end'); e.target.dispatchEvent(new Event('input')); } });
$('modelMenu').addEventListener('click', showModelDialog); $('modelHelp').addEventListener('click', showModelDialog); $('closeModelDialog').addEventListener('click', () => $('modelDialog').classList.add('hidden')); $('modelDialog').addEventListener('click', e => { if (e.target === $('modelDialog')) $('modelDialog').classList.add('hidden'); });
$('installOllama').addEventListener('click', async () => { await window.oficina.openOllamaDownload(); });
$('pullModel').addEventListener('click', () => pullModelByTag($('modelToInstall').value));
$('addCustomModel').addEventListener('click', () => {
  const model = $('customModelInput').value.trim();
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,120}$/.test(model)) return toast('Digite uma tag Ollama válida, por exemplo qwen2.5-coder:7b.', 'error');
  $('customModelInput').value = ''; pullModelByTag(model);
});
$('customModelInput').addEventListener('keydown', e => { if (e.key === 'Enter') $('addCustomModel').click(); });
$('openModelGarden').addEventListener('click', () => window.oficina.openExternal('https://console.cloud.google.com/agent-platform/publishers/google/model-garden/364?hl=pt-br'));
window.oficina.onPullProgress(data => { $('pullStatus').textContent = data.percent == null ? data.status : `${data.status} · ${data.percent}%`; });
  $('generateButton').addEventListener('click', generate); $('clearPrompt').addEventListener('click', () => { $('promptInput').value = ''; $('promptCount').textContent = '0 / 12.000'; });
$('promptInput').addEventListener('input', () => { if ($('promptInput').value.length > 12000) $('promptInput').value = $('promptInput').value.slice(0, 12000); $('promptCount').textContent = `${$('promptInput').value.length.toLocaleString('pt-BR')} / 12.000`; });
  function appendTerminalOutput(data) {
    const out = $('terminalContent');
    out.textContent += String(data);
    if (out.textContent.length > 500000) out.textContent = out.textContent.slice(-500000);
    out.scrollTop = out.scrollHeight;
  }
  $('commandForm').addEventListener('submit', async e => {
    e.preventDefault();
    if (!state.workspace) return toast('Abra uma pasta de projeto primeiro.');
    const command = $('commandInput').value.trim();
    if (!command) return;
    if (state.commandHistory.at(-1) !== command) state.commandHistory.push(command);
    if (state.commandHistory.length > 100) state.commandHistory.shift();
    state.commandHistoryIndex = state.commandHistory.length;
    $('commandInput').value = ''; $('runCommand').disabled = true; $('stopCommand').classList.remove('hidden');
    try { await window.oficina.runCommand(command); }
    catch (e) { toast(e.message, 'error'); }
    finally { $('runCommand').disabled = false; $('stopCommand').classList.add('hidden'); }
  });
  $('commandInput').addEventListener('keydown', e => {
    if (e.key === 'ArrowUp' && state.commandHistory.length) { e.preventDefault(); state.commandHistoryIndex = Math.max(0, state.commandHistoryIndex - 1); $('commandInput').value = state.commandHistory[state.commandHistoryIndex]; }
    else if (e.key === 'ArrowDown' && state.commandHistory.length) { e.preventDefault(); state.commandHistoryIndex = Math.min(state.commandHistory.length, state.commandHistoryIndex + 1); $('commandInput').value = state.commandHistory[state.commandHistoryIndex] || ''; }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') { e.preventDefault(); $('terminalContent').textContent = ''; }
  });
  window.oficina.onTerminalData(appendTerminalOutput);
  window.oficina.onTerminalDone(result => { appendTerminalOutput(`\r\n[processo finalizado · código ${result.code}]\r\n`); refreshDevInfo(); });
  $('quickCommandSelect').addEventListener('change', e => { const action = e.target.value; e.target.value = ''; if (action) selectQuickCommand(action); });
  $('createPythonVenv').addEventListener('click', () => selectQuickCommand('python-venv'));
  $('installPythonPackage').addEventListener('click', installPythonPackagesFromPrompt);
  $('installPythonTools').addEventListener('click', () => selectQuickCommand('python-tools'));
  $('installNodeTools').addEventListener('click', () => selectQuickCommand('node-tools'));
  $('stopCommand').addEventListener('click', () => window.oficina.stopCommand());
  $('clearTerminal').addEventListener('click', () => { $('terminalContent').textContent = ''; });
  $('toggleTerminal').addEventListener('click', () => { $('terminalPanel').classList.remove('maximized'); $('terminalPanel').classList.toggle('collapsed'); });
  $('toggleTerminalMax').addEventListener('click', () => {
    const panel = $('terminalPanel'); const maximized = panel.classList.toggle('maximized');
    panel.classList.remove('collapsed'); $('toggleTerminalMax').textContent = maximized ? '❐' : '□'; $('toggleTerminalMax').title = maximized ? 'Restaurar terminal' : 'Maximizar terminal';
  });
  const terminalSash = $('terminalResize');
  terminalSash.addEventListener('pointerdown', e => {
    if (e.button !== 0 || $('terminalPanel').classList.contains('maximized')) return;
    e.preventDefault(); $('terminalPanel').classList.remove('collapsed');
    state.terminalDrag = { y: e.clientY, height: $('terminalPanel').getBoundingClientRect().height };
    terminalSash.setPointerCapture(e.pointerId);
  });
  terminalSash.addEventListener('pointermove', e => {
    if (!state.terminalDrag) return;
    const ceiling = Math.max(170, $('centerColumn').clientHeight * 0.72);
    const height = Math.max(170, Math.min(ceiling, state.terminalDrag.height + state.terminalDrag.y - e.clientY));
    $('terminalPanel').style.height = `${height}px`;
  });
  const finishTerminalResize = () => {
    if (!state.terminalDrag) return;
    state.terminalDrag = null;
    try { localStorage.setItem('oficina-terminal-height', String(Math.round($('terminalPanel').getBoundingClientRect().height))); } catch (_) {}
  };
  terminalSash.addEventListener('pointerup', finishTerminalResize); terminalSash.addEventListener('pointercancel', finishTerminalResize);
  try { const savedHeight = Number(localStorage.getItem('oficina-terminal-height')); if (Number.isFinite(savedHeight) && savedHeight >= 170) $('terminalPanel').style.height = `${Math.min(savedHeight, window.innerHeight * 0.65)}px`; } catch (_) {}
$('promptInput').addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') generate(); }); document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); saveCurrent(); } });

checkOllama().then(status => {
  if (!status.ok) { setStatus('Ollama não conectado — configure para começar'); showModelDialog(); }
  else if (!status.models.length) { setStatus('Ollama ativo — instale um modelo para começar'); showModelDialog(); }
  else setStatus('Ollama ativo · ' + status.models.length + ' modelo(s)');
});
