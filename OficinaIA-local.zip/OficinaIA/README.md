# Oficina IA — editor local com Ollama

Aplicativo desktop gratuito, com aparência inspirada em IDEs. Você descreve em português o que quer construir; o modelo local prepara uma proposta de arquivos, que só é gravada na pasta do projeto depois da sua confirmação.

## O que mudou nesta versão

- Lista dinamicamente os modelos que já estão instalados pelo Ollama.
- Catálogo para baixar opções locais de código, modelos Mistral e outros modelos disponíveis na biblioteca Ollama.
- Destaques indicam o perfil de cada modelo (código, leve, geral ou avançado), tamanho do download e notas de licença/hardware.
- Permite colar uma tag publicada no Ollama para baixar modelos além dos destaques.
- Exibe o Google Model Garden como **referência externa**. O Oficina IA não conecta ao Google Cloud nem envia pedidos para serviços remotos; a geração continua usando Ollama neste computador.

## Modelos destacados

Os tamanhos abaixo são os downloads das variantes quantizadas listadas pelo Ollama. **Não são requisitos de RAM/VRAM.** A execução exige memória adicional para pesos carregados, runtime e contexto, e a velocidade varia conforme computador, backend e configuração.

| Perfil no app | Modelo / tag Ollama | Tamanho do download | Observações |
| --- | --- | ---: | --- |
| Destaque para programação | [Qwen3-Coder 30B](https://ollama.com/library/qwen3-coder:30b) · `qwen3-coder:30b` | 19 GB | Especializado em código; exige bastante memória local. Licença Apache 2.0. |
| Código equilibrado | [Qwen2.5-Coder 7B](https://ollama.com/library/qwen2.5-coder:7b) · `qwen2.5-coder:7b` | 4,7 GB | Opção de código menor que os modelos 14B/30B. Licença Apache 2.0. |
| Leve para código | [IBM Granite Code 3B](https://ollama.com/library/granite-code:3b) · `granite-code:3b` | 2,0 GB | Geração, explicação e correção de código; Apache 2.0. |
| Geral + programação | [Mistral Nemo 12B](https://ollama.com/library/mistral-nemo:12b) · `mistral-nemo:12b` | 7,1 GB | Modelo geral com apoio à programação; Apache 2.0. |
| Código · MoE | [DeepSeek-Coder V2 16B](https://ollama.com/library/deepseek-coder-v2:16b) · `deepseek-coder-v2:16b` | 8,9 GB | Licença dos pesos tem termos próprios; confira antes de uso comercial. |
| Repositórios · Mistral | [Devstral Small 2 24B](https://ollama.com/library/devstral-small-2:24b) · `devstral-small-2:24b` | 15 GB | Modelo maior; o Ollama indica versão 0.13.3 ou posterior. Apache 2.0. |
| Alternativa pequena | [Qwen2.5-Coder 3B](https://ollama.com/library/qwen2.5-coder:3b) · `qwen2.5-coder:3b` | 1,9 GB | A ficha do Ollama identifica **Qwen Research License Agreement**. Leia os termos; não o trate como liberado para uso comercial. Granite Code 3B é a opção compacta Apache 2.0. |

A lista traz modelos de famílias diferentes; não promete uma classificação universal nem desempenho igual em todos os computadores. O app não executa ferramentas do modelo por conta própria: ele envia o pedido e o contexto ao Ollama e prepara arquivos para você revisar.

**Codestral não está entre os destaques para download:** a ficha do Ollama informa Mistral AI Non-Production License; uso comercial requer licença adicional. É possível inserir uma tag manualmente, mas confira os termos do modelo antes de usar.

## Requisitos

- Windows 10+, macOS 14+ ou Linux x64/arm64.
- Node.js 20 ou mais recente (inclui `npm`). Baixe gratuitamente em [nodejs.org](https://nodejs.org/).
- Ollama instalado localmente. Baixe gratuitamente em [ollama.com/download](https://ollama.com/download).
- Internet para baixar o Electron na primeira execução e os modelos escolhidos.
- Espaço em disco e memória compatíveis com o modelo. O app mostra o tamanho do download, mas não calcula a memória disponível no seu computador.

## Primeira execução

### Windows

1. Instale Node.js LTS e Ollama pelos sites oficiais acima.
2. Abra o Ollama e aguarde iniciar.
3. Extraia o ZIP para uma pasta (por exemplo, Documentos).
4. Abra `iniciar-windows.bat`. Na primeira vez, ele baixa as dependências gratuitas do Electron.
5. No app, abra **Modelo**. Baixe um destaque ou selecione uma tag já instalada.
6. Clique em **Abrir pasta**, selecione uma pasta de projeto e escreva sua ideia no painel **Assistente**.
7. Revise a proposta e clique em **Aplicar ao projeto**. Arquivos que serão substituídos têm cópia de segurança em `.oficina-backups/`.

### macOS

Instale Node.js e Ollama; abra Ollama. No Terminal, entre na pasta extraída e rode:

```bash
chmod +x iniciar-macos.command iniciar-linux.sh
./iniciar-macos.command
```

### Linux

Instale Node.js e Ollama, confirme que o serviço Ollama está ativo e rode:

```bash
chmod +x iniciar-linux.sh
./iniciar-linux.sh
```

### Execução manual

```bash
npm install
npm start
```

## Model Garden do Google

O link do [Google Model Garden](https://console.cloud.google.com/agent-platform/publishers/google/model-garden/364?hl=pt-br) aparece no diálogo de modelos apenas para consulta. **Não há integração com Vertex AI/Google Cloud nesta versão**, então não é possível escolher ou executar esses modelos hospedados dentro do Oficina IA. Essa separação mantém o app local, sem credenciais nem uso de API em nuvem.

## Segurança e limites

- A geração não grava nem executa código automaticamente. Você revisa a proposta e confirma; substituições geram cópias em `.oficina-backups/`.
- O terminal só roda um comando após seu clique; execute apenas comandos que você entenda e confie.
- O editor trabalha dentro da pasta escolhida e suporta arquivos de texto de até 2 MB.
- A lista oficial de modelos Ollama pode mudar. O campo de tag manual aceita outras tags, mas a licença e as necessidades de hardware são específicas de cada modelo.
- Este é um MVP: não inclui extensões VS Code, depurador visual nem entrada por microfone.

## Testes do projeto

```bash
npm run check
npm test
```

## Fontes oficiais

- [Ollama — downloads](https://ollama.com/download)
- [Qwen3-Coder 30B](https://ollama.com/library/qwen3-coder:30b)
- [Qwen2.5-Coder 7B](https://ollama.com/library/qwen2.5-coder:7b)
- [Granite Code 3B](https://ollama.com/library/granite-code:3b)
- [Mistral Nemo 12B](https://ollama.com/library/mistral-nemo:12b)
- [Devstral Small 2 24B](https://ollama.com/library/devstral-small-2:24b)
- [DeepSeek-Coder V2 16B](https://ollama.com/library/deepseek-coder-v2:16b)
- [Google Model Garden](https://console.cloud.google.com/agent-platform/publishers/google/model-garden/364?hl=pt-br)
- [Electron](https://www.electronjs.org/)
