window.MODEL_CATALOG = [
  {
    tag: 'qwen3-coder:30b',
    name: 'Qwen3-Coder 30B · Qwen',
    group: 'Destaque para programação',
    badge: 'Destaque · código avançado',
    size: '19 GB · Q4_K_M',
    hardware: 'uso de memória alto',
    featured: true,
    recommendation: 'Para tarefas de código mais complexas, se o computador tiver memória suficiente.',
    description: 'Família especializada em código, com 30,5B parâmetros totais. O aplicativo usa prompt e contexto local para gerar arquivos; não habilita ferramentas agentivas do modelo. Download de 19 GB, mas execução requer memória adicional. Apache 2.0.',
    url: 'https://ollama.com/library/qwen3-coder:30b'
  },
  {
    tag: 'qwen2.5-coder:7b',
    name: 'Qwen2.5-Coder 7B · Qwen',
    group: 'Código com download menor',
    badge: 'Equilibrado · código',
    size: '4,7 GB · Q4_K_M',
    hardware: 'uso de memória moderado',
    featured: true,
    recommendation: 'Ponto de partida para gerar, explicar e corrigir código.',
    description: 'Modelo especializado em código, menor que as variantes 14B/32B. O consumo real depende do contexto e do seu computador. Apache 2.0.',
    url: 'https://ollama.com/library/qwen2.5-coder:7b'
  },
  {
    tag: 'granite-code:3b',
    name: 'Granite Code 3B · IBM',
    group: 'Código com download menor',
    badge: 'Leve · código',
    size: '2,0 GB · Q4_0',
    hardware: 'menor download da lista',
    featured: true,
    recommendation: 'Geração, explicação e correção de código com download compacto.',
    description: 'Modelo de código pequeno para máquinas com menos espaço disponível. A qualidade e velocidade variam; instruções complexas podem exigir um modelo maior. Apache 2.0.',
    url: 'https://ollama.com/library/granite-code:3b'
  },
  {
    tag: 'qwen2.5-coder:3b',
    name: 'Qwen2.5-Coder 3B · Qwen',
    group: 'Alternativas com licença específica',
    badge: 'Leia a licença',
    size: '1,9 GB · Q4_K_M',
    hardware: 'download pequeno',
    featured: false,
    recommendation: 'Opção pequena; a ficha do Ollama identifica licença Qwen Research.',
    description: 'A licença desta variante é diferente da tag 7B: confira os termos oficiais e não a considere liberada para uso comercial sem verificar. Para uma alternativa compacta com Apache 2.0, veja Granite Code 3B (2,0 GB).',
    url: 'https://ollama.com/library/qwen2.5-coder:3b'
  },
  {
    tag: 'mistral-nemo:12b',
    name: 'Mistral Nemo 12B · Mistral + NVIDIA',
    group: 'Modelos Mistral',
    badge: 'Geral + programação',
    size: '7,1 GB · Q4_0',
    hardware: 'uso de memória moderado/alto',
    featured: true,
    recommendation: 'Assistente geral local com apoio à programação.',
    description: 'Modelo geral de instruções com capacidade de código e contexto anunciado de até 128K; contexto longo aumenta o consumo de memória. Apache 2.0.',
    url: 'https://ollama.com/library/mistral-nemo:12b'
  },
  {
    tag: 'deepseek-coder-v2:16b',
    name: 'DeepSeek-Coder V2 16B',
    group: 'Modelos de código avançados',
    badge: 'Código · MoE',
    size: '8,9 GB · Q4_0',
    hardware: 'uso de memória alto',
    featured: false,
    recommendation: 'Alternativa local focada em completar e corrigir código.',
    description: 'Variante local 16B/Lite, quantizada. O arquivo baixado não representa a memória total em uso; leia os termos específicos da licença do modelo antes de uso comercial.',
    url: 'https://ollama.com/library/deepseek-coder-v2:16b'
  },
  {
    tag: 'devstral-small-2:24b',
    name: 'Devstral Small 2 24B · Mistral',
    group: 'Modelos Mistral',
    badge: 'Repositórios · agentivo',
    size: '15 GB · Q4_K_M',
    hardware: 'uso de memória alto',
    featured: false,
    recommendation: 'Ajuda a explorar repositórios e propor mudanças em vários arquivos.',
    description: 'Modelo local maior, com foco agentivo e compreensão de repositórios. A ficha Ollama indica Ollama 0.13.3 ou posterior. Apache 2.0; precisa de espaço e memória adicionais para execução/contexto.',
    url: 'https://ollama.com/library/devstral-small-2:24b'
  }
];
