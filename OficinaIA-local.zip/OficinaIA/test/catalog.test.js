const test = require('node:test');
const assert = require('node:assert/strict');

global.window = {};
require('../model-catalog');
const catalog = global.window.MODEL_CATALOG;

test('catálogo tem tags únicas e links HTTPS para fichas oficiais Ollama', () => {
  assert.ok(Array.isArray(catalog));
  assert.ok(catalog.length >= 6);
  const tags = catalog.map(item => item.tag);
  assert.equal(new Set(tags).size, tags.length);
  for (const item of catalog) {
    assert.match(item.tag, /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._-]*$/i);
    const url = new URL(item.url);
    assert.equal(url.protocol, 'https:');
    assert.equal(url.hostname, 'ollama.com');
    assert.ok(item.name && item.group && item.badge && item.size && item.description);
  }
});

test('destaques incluem código leve, Qwen, Mistral e referência cautelosa de licença', () => {
  const tags = new Set(catalog.map(item => item.tag));
  assert.ok(tags.has('granite-code:3b'));
  assert.ok(tags.has('qwen2.5-coder:7b'));
  assert.ok(tags.has('qwen3-coder:30b'));
  assert.ok(tags.has('mistral-nemo:12b'));
  assert.ok(tags.has('devstral-small-2:24b'));
  const research = catalog.find(item => item.tag === 'qwen2.5-coder:3b');
  assert.match(research.description, /licença|termos/i);
});
